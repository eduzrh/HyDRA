# 训练停止条件说明

## 功能描述

在生成 `hypergraph_neural_top_pairs.txt` 时，会检查以下停止条件：

1. **独立KG1实体数量 < 50**：如果输出的实体对中独立的KG1实体数量小于50，停止训练
2. **评估轮次 > 3**：如果评估轮次超过3轮，停止训练

满足任一条件时，训练会立即停止。

## 实现位置

- **检查代码**：`CSLS_.py` 的 `eval_alignment_by_sim_mat` 函数
- **停止处理**：`main_SimpleHHEA.py` 的 `train` 函数

## 工作流程

1. 每次评估时（每10个epoch），`eval_alignment_by_sim_mat` 函数会被调用
2. 在 `save_load_similar_entities` 保存 `hypergraph_neural_top_pairs.txt` 之后，立即检查停止条件
3. 统计独立的KG1实体数量（从保存的实体对中提取）
4. 从 `.eval_round` 文件读取当前轮次（如果存在），否则从1开始
5. 检查条件：
   - 如果独立KG1实体数量 < 50 → 停止
   - 如果评估轮次 > 3 → 停止
6. 如果满足停止条件：
   - 打印停止消息
   - 清理 `.eval_round` 文件
   - 抛出 `StopIteration` 异常
7. `train` 函数捕获异常并停止训练循环

## 轮次文件

- **文件位置**：`data/{dataset}/message_pool/.eval_round`
- **作用**：记录当前评估轮次
- **格式**：单个整数
- **清理**：满足停止条件后自动删除

## 示例输出

当满足停止条件时，会输出：

```
================================================================================
Stop condition met: Unique KG1 entities (45) < 50
Unique KG1 entities: 45, Current round: 2
================================================================================

Training stopped: Training stopped: Unique KG1 entities (45) < 50
```

## 注意事项

1. 评估轮次从1开始计数
2. 每次评估时轮次递增
3. 停止条件是"或"关系（满足任一条件即停止）
4. 训练停止后，`.eval_round` 文件会被清理，下次训练从头开始计数
