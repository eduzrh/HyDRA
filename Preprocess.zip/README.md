# Preprocess

Preprocessing pipeline for large-scale temporal knowledge graph alignment, following [ELsEA](https://www.computer.org/csdl/proceedings-article/icde/2025/360300c227/26FZAKCH0Os).

Includes:
- **ElSEA** — entity alignment pre-processing (structural encoding, context building, seed selection)
- **DivEA** — distributed partitioning of large-scale KGs into parallelizable subtasks

---

## Environment Setup

```bash
# 1. Create environment and install dependencies
conda create --name qzhou_LargerEA_py310
conda activate qzhou_LargerEA_py310
# Then follow the steps in Install_requirements

# 2. Download translation model (for entity name embedding)
# Place the Helsinki-NLP model files into:
#   ./DivEA/Unsuper/TranslatetoEN/
```

---

## Running ElSEA + DivEA

```bash
cd DivEA
python run_large_scale.py --dataset 1m --kgids en,de --ea_model hydra --eval_way sinkhorn
```

Key arguments:

| Argument | Options | Description |
|:---|:---|:---|
| `--dataset` | `1m`, `2m`, `...` | Dataset |
| `--kgids` | e.g. `en,de`, `fr,en` | KG pair to align |
| `--ea_model` | `rrea`, `dualamn`, `gcn-align`, `hydra` | EA method |
| `--subtask_size` | int | Number of entities per subtask (partition count = total / subtask_size) |
| `--ctx_g1_percent` | float | Fraction of G1 entities included as context |
| `--eval_way` | `csls`, `cosine`, `sinkhorn` | Evaluation metric |
| `--ctx_builder` | `v1`, `v2` | Context building strategy |

See `run_large_scale.py` for all available options.

---

## Citation

This work builds on:
- [ELsEA (ICDE 2025)](https://github.com/uqbingliu/DivEA)
- [RREA](https://github.com/MaoXinn/RREA)
- [GCN-Align](https://github.com/1049451037/GCN-Align)
- [Dual-AMN](https://github.com/ZJU-DAILY/DualMatch)

```bibtex
@inproceedings{Zhou2025,
  title={Enhancing Large-scale Entity Alignment with Critical Structure and High-quality Context},
  author={Zhou, Qian and Chen, Wei and Zhang, Li and Zhao, Pengpeng and Xu, Jiajie and Zhao, Lei},
  booktitle={ICDE},
  year={2025}
}
```
