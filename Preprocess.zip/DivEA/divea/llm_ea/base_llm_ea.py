# -*- coding: utf-8 -*-
"""
Base class for LLM-based Entity Alignment NeuralEAModule implementations.

LLM-based EA methods differ from embedding-based ones:
  - They use entity text names/descriptions (not just integer IDs)
  - They call an LLM to predict alignment pairs
  - They typically don't produce embedding matrices naturally
  - For framework compatibility, we encode entity names as embeddings

All LLM-based EA wrappers inherit from this base and only need to implement:
  _build_prompts() → build prompts for the LLM
  _parse_response() → parse LLM output into alignment pairs
  _run_alignment()  → orchestrate the LLM-based alignment process
"""

import os
import json
import numpy as np
from abc import abstractmethod
from typing import List, Tuple, Dict, Optional

from RREA.CSLS_torch import Evaluator

from divea.util import Config
from divea.dataload import read_alignment
from divea.convert_to_hydra import convert_uniform_to_hydra, uri_to_name, read_tab_lines
from divea.components_base import NeuralEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class BaseLLMEAModule(NeuralEAModule):
    """Base class for LLM-based EA methods.
    
    Subclasses override:
      - _run_alignment(data_dir, output_dir) → main LLM alignment logic
      - method_name (class attribute) → short identifier
    """
    
    method_name: str = 'llm_ea'
    
    def __init__(self, conf: Config, llm_backend: LLMBackend = None):
        super().__init__(conf)
        self.llm = llm_backend or MockBackend()
        self._entity_texts_1: Dict[int, str] = {}
        self._entity_texts_2: Dict[int, str] = {}
        self.predicted_pairs: List[Tuple[int, int]] = []
        
        # Global data dir for entity name mapping
        self.global_data_dir = getattr(conf, 'llm_global_data_dir', None)
        if self.global_data_dir is None:
            self.global_data_dir = os.path.dirname(self.conf.data_dir)
    
    # ── NeuralEAModule Interface ──
    
    def refresh_weights(self):
        pass
    
    def prepare_data(self):
        """Convert partition data and extract entity names."""
        print(f'[{self.method_name}] prepare_data: {self.conf.data_dir}')
        
        # Use HyDRA converter to get entity names
        convert_uniform_to_hydra(
            self.conf.data_dir,
            self.conf.kgids,
            global_data_dir=self.global_data_dir
        )
        
        # Load entity names into cache
        self._load_entity_texts()
    
    def _load_entity_texts(self):
        """Load entity ID → name mappings from ent_ids_1 and ent_ids_2."""
        for line in read_tab_lines(os.path.join(self.conf.data_dir, 'ent_ids_1')):
            if len(line) >= 2:
                self._entity_texts_1[int(line[0])] = line[1]
        
        for line in read_tab_lines(os.path.join(self.conf.data_dir, 'ent_ids_2')):
            if len(line) >= 2:
                self._entity_texts_2[int(line[0])] = line[1]
    
    def _load_triples(self) -> Tuple[List, List]:
        """Load triples from data_dir."""
        triples_1 = [(int(t[0]), int(t[1]), int(t[2])) 
                     for t in read_tab_lines(os.path.join(self.conf.data_dir, 'triples_1'))
                     if len(t) >= 3]
        triples_2 = [(int(t[0]), int(t[1]), int(t[2]))
                     for t in read_tab_lines(os.path.join(self.conf.data_dir, 'triples_2'))
                     if len(t) >= 3]
        return triples_1, triples_2
    
    def _load_train_pairs(self) -> List[Tuple[int, int]]:
        """Load training alignment pairs."""
        fn = os.path.join(self.conf.data_dir, 'sup_pairs')
        if not os.path.exists(fn):
            fn = os.path.join(self.conf.data_dir, 'ref_ent_ids_train')
        if not os.path.exists(fn):
            fn = os.path.join(self.conf.data_dir, 'train_alignment.txt')
        if os.path.exists(fn):
            return [(int(t[0]), int(t[1])) for t in read_tab_lines(fn) if len(t) >= 2]
        return []
    
    def _load_test_pairs(self) -> List[Tuple[int, int]]:
        """Load test alignment pairs."""
        fn = os.path.join(self.conf.data_dir, 'ref_ent_ids')
        if not os.path.exists(fn):
            fn = os.path.join(self.conf.data_dir, 'ref_ent_ids_test')
        if not os.path.exists(fn):
            fn = os.path.join(self.conf.data_dir, 'test_alignment.txt')
        if os.path.exists(fn):
            return [(int(t[0]), int(t[1])) for t in read_tab_lines(fn) if len(t) >= 2]
        return []
    
    def _get_neighbor_texts(self, entity_id: int, kg: int = 1, max_neighbors: int = 5) -> str:
        """Get neighbor entity names for context."""
        triples = self._triples_1 if kg == 1 else self._triples_2
        texts = self._entity_texts_1 if kg == 1 else self._entity_texts_2
        
        neighbors = []
        for h, r, t in triples:
            if h == entity_id and len(neighbors) < max_neighbors:
                neighbors.append(texts.get(t, f'E{t}'))
            elif t == entity_id and len(neighbors) < max_neighbors:
                neighbors.append(texts.get(h, f'E{h}'))
            if len(neighbors) >= max_neighbors:
                break
        
        return ', '.join(neighbors) if neighbors else '(no neighbors)'
    
    def train_model(self):
        """Run LLM-based alignment."""
        print(f'[{self.method_name}] train_model')
        
        # Cache triples for neighbor lookup
        self._triples_1, self._triples_2 = self._load_triples()
        
        # Run the method-specific alignment
        self.predicted_pairs = self._run_alignment(
            self.conf.data_dir, self.conf.output_dir
        )
        
        # Encode entity names as embeddings (for evaluation compatibility)
        self._encode_entity_names()
        
        print(f'[{self.method_name}] Predicted {len(self.predicted_pairs)} alignment pairs')
    
    @abstractmethod
    def _run_alignment(self, data_dir: str, output_dir: str) -> List[Tuple[int, int]]:
        """Run the LLM-based alignment. Returns predicted pairs.
        
        Subclasses MUST implement this.
        """
        pass
    
    def _encode_entity_names(self):
        """Encode entity names to embeddings using LLM/fallback backend.
        
        This produces emb.npz for framework compatibility.
        LLM EA methods don't naturally produce embeddings, so we encode
        entity names using the backend's embed() function.
        """
        ent1_names = [self._entity_texts_1.get(i, f'E{i}') 
                      for i in sorted(self._entity_texts_1.keys())]
        ent2_names = [self._entity_texts_2.get(i, f'E{i}')
                      for i in sorted(self._entity_texts_2.keys())]
        
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)
        
        n1, d = ent1_embs.shape
        n2 = ent2_embs.shape[0]
        
        all_embs = np.concatenate([ent1_embs, ent2_embs], axis=0).astype(np.float32)
        
        np.savez(
            os.path.join(self.conf.output_dir, 'emb.npz'),
            embs=all_embs,
            ent1_ids=np.arange(n1),
            ent2_ids=np.arange(n1, n1 + n2),
        )
        print(f'[{self.method_name}] Encoded {n1}+{n2} entities, dim={d}')
    
    def predict_simi(self):
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        evaluator = Evaluator(device=self.conf.torch_device)
        return evaluator.csls_sim(embs[ent1_ids], embs[ent2_ids], k=10)
    
    def get_embeddings(self):
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        return emb_res['embs'][emb_res['ent1_ids']], emb_res['embs'][emb_res['ent2_ids']]
    
    def get_pred_alignment(self, eval_way='sinkhorn'):
        pred_fn = os.path.join(self.conf.output_dir, 'pred_alignment.json')
        if os.path.exists(pred_fn):
            with open(pred_fn) as f:
                obj = json.loads(f.read())
            return obj.get(f'pred_alignment_{eval_way}', [])
        return self.predicted_pairs
    
    def evaluate(self, eval_way='sinkhorn'):
        """Evaluate predicted alignments against ground truth."""
        print(f'[{self.method_name}] evaluate')
        
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        ent1_embs = embs[ent1_ids]
        ent2_embs = embs[ent2_ids]
        
        eval_alignment = read_alignment(os.path.join(self.conf.data_dir, 'test_alignment.txt'))
        
        evaluator = Evaluator(device=self.conf.torch_device)
        
        sinkhorn_test_metrics, sinkhorn_test_alignment = [], []
        csls_test_metrics, csls_test_alignment = [], []
        cosine_test_metrics, cosine_test_alignment = [], []
        
        if eval_way == 'sinkhorn':
            sinkhorn_test_metrics, sinkhorn_test_alignment = evaluator.evaluate_sinkhorn(
                ent1_embs, ent2_embs, eval_alignment)
            sinkhorn_test_alignment = sinkhorn_test_alignment.tolist()
        elif eval_way == 'csls':
            csls_test_metrics, csls_test_alignment = evaluator.evaluate_csls(
                ent1_embs, ent2_embs, eval_alignment)
            csls_test_alignment = csls_test_alignment.tolist()
        elif eval_way == 'cosine':
            cosine_test_metrics, cosine_test_alignment = evaluator.evaluate_cosine(
                ent1_embs, ent2_embs, eval_alignment)
            cosine_test_alignment = cosine_test_alignment.tolist()
        
        all_alignment = evaluator.predict_alignment(ent1_embs, ent2_embs, eval_way=eval_way)
        
        metrics_obj = {
            'metrics_sinkhorn': sinkhorn_test_metrics,
            'metrics_csls': csls_test_metrics,
            'metrics_cos': cosine_test_metrics,
        }
        pred_alignment_obj = {
            'pred_alignment_sinkhorn': sinkhorn_test_alignment,
            'pred_alignment_csls': csls_test_alignment,
            'pred_alignment_cos': cosine_test_alignment,
            'all_pred_alignment': all_alignment.tolist(),
        }
        
        with open(os.path.join(self.conf.output_dir, 'metrics.json'), 'w+') as f:
            f.write(json.dumps(metrics_obj))
        with open(os.path.join(self.conf.output_dir, 'pred_alignment.json'), 'w+') as f:
            f.write(json.dumps(pred_alignment_obj))
        with open(os.path.join(self.conf.output_dir, 'eval_metrics.json'), 'w+') as f:
            if eval_way == 'sinkhorn':
                f.write(json.dumps(sinkhorn_test_metrics))
            elif eval_way == 'csls':
                f.write(json.dumps(csls_test_metrics))
            elif eval_way == 'cosine':
                f.write(json.dumps(cosine_test_metrics))
        
        return metrics_obj
    
    def evaluate_given_alignment(self, eval_alignment):
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        
        evaluator = Evaluator(device=self.conf.torch_device)
        s, _ = evaluator.evaluate_sinkhorn(embs[ent1_ids], embs[ent2_ids], eval_alignment)
        c, _ = evaluator.evaluate_csls(embs[ent1_ids], embs[ent2_ids], eval_alignment)
        co, _ = evaluator.evaluate_cosine(embs[ent1_ids], embs[ent2_ids], eval_alignment)
        
        return s, c, co
