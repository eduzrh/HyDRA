# Fualign
A novel cross-lingual entity alignment framework based on multi-view KRL of a pre-fused knowledge graph.
## environment
* networkx
* gensim
* pytorch1.6
## usage
```
cd fualign
mkdir result
./preproccess.sh
./train.sh
./evaluate.sh
```
