#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Download and prepare the LargeTKGA dataset from HuggingFace.

Dataset: https://huggingface.co/datasets/knowledgeAnonymous/LargeTKGA
Password: largetkga

Usage:
    python download_largetkga.py --output_dir ./data

This script will:
  1. Download the LargeTKGA dataset from HuggingFace
  2. Extract the archive (encrypted with password: largetkga)
  3. Organize files into the expected directory structure
  4. Convert to ELsEA format (if needed)
"""

import os
import sys
import json
import argparse
import zipfile
import tarfile
import rarfile
import subprocess
from pathlib import Path


DATASET_INFO = {
    'TimeD1M/EN-FR': {
        'hf_path': 'TimeD1M/en_fr',
        'description': 'Time-aware DBpedia 1M EN-FR (1 million entities per KG)',
        'kgids': ('en', 'fr'),
        'temporal': True,
        'time_granularity': 'month',  # YYYY-MM format
    },
    'TimeD1M/EN-DE': {
        'hf_path': 'TimeD1M/en_de',
        'description': 'Time-aware DBpedia 1M EN-DE (1 million entities per KG)',
        'kgids': ('en', 'de'),
        'temporal': True,
        'time_granularity': 'month',
    },
    'Time-FB2M': {
        'hf_path': 'TimeFB2M/fb_dbp',
        'description': 'Time-aware Freebase-DBpedia 2M (2 million entities)',
        'kgids': ('fb', 'dbp'),
        'temporal': True,
        'time_granularity': 'day',  # YYYY-MM-DD format
    },
}

HF_DATASET_ID = 'knowledgeAnonymous/LargeTKGA'
PASSWORD = 'largetkga'


def extract_archive(archive_path, output_dir, password=None):
    """Extract archive with password support."""
    archive_path = str(archive_path)
    print(f"  Extracting {os.path.basename(archive_path)}...")

    if archive_path.endswith('.zip'):
        with zipfile.ZipFile(archive_path, 'r') as zf:
            if password:
                zf.setpassword(password.encode())
            zf.extractall(output_dir)
    elif archive_path.endswith('.tar.gz') or archive_path.endswith('.tgz'):
        with tarfile.open(archive_path, 'r:gz') as tf:
            tf.extractall(output_dir)
    elif archive_path.endswith('.tar'):
        with tarfile.open(archive_path, 'r:') as tf:
            tf.extractall(output_dir)
    elif archive_path.endswith('.rar'):
        if password:
            rarfile.UNRAR_TOOL = 'unrar'
        with rarfile.RarFile(archive_path, 'r') as rf:
            if password:
                rf.extractall(output_dir)
            else:
                rf.extractall(output_dir)
    else:
        print(f"  Warning: Unknown archive format: {archive_path}")
        return False
    return True


def try_download_with_hf():
    """Try downloading using huggingface_hub."""
    try:
        from huggingface_hub import snapshot_download
        print("  Attempting download via huggingface_hub...")
        cache_dir = os.path.join(os.path.expanduser('~'), '.cache', 'huggingface', 'datasets')
        path = snapshot_download(
            repo_id=HF_DATASET_ID,
            repo_type='dataset',
            cache_dir=cache_dir,
            local_dir_use_symlinks=False,
        )
        return path
    except ImportError:
        return None
    except Exception as e:
        print(f"  huggingface_hub error: {e}")
        return None


def try_download_with_hf_cli():
    """Try downloading using hf CLI."""
    import shutil
    try:
        hf_path = shutil.which('hf')
        if not hf_path:
            # Try pip install
            subprocess.run([sys.executable, '-m', 'pip', 'install', 'huggingface_hub', '-q'],
                         capture_output=True)
            hf_path = shutil.which('hf')

        if hf_path:
            cache_dir = os.path.join(os.path.expanduser('~'), '.cache', 'huggingface', 'datasets')
            output = os.path.join(cache_dir, HF_DATASET_ID.replace('/', '_'))
            result = subprocess.run(
                ['hf', 'download', '--type', 'dataset',
                 '--local-dir', output, HF_DATASET_ID],
                capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0:
                return output
    except Exception as e:
        print(f"  hf CLI error: {e}")
    return None


def try_download_with_wget(url, output_file):
    """Try downloading with wget."""
    try:
        result = subprocess.run(
            ['wget', '-O', output_file, '--no-check-certificate',
             '--user', 'anonymous', '--password', PASSWORD, url],
            capture_output=True, text=True, timeout=600
        )
        if result.returncode == 0 and os.path.exists(output_file):
            return True
    except Exception as e:
        print(f"  wget error: {e}")
    return False


def download_via_api():
    """Download using HuggingFace API directly."""
    import requests
    try:
        # List files in the repo
        api_url = f"https://huggingface.co/api/datasets/{HF_DATASET_ID}/tree/main"
        resp = requests.get(api_url, timeout=30)
        if resp.status_code != 200:
            return None
        files = resp.json()
        print(f"  Found {len(files)} files in dataset")

        # Get download URLs
        download_urls = []
        for f in files:
            if isinstance(f, dict):
                download_urls.append(f.get('download', f.get('path')))
            else:
                download_urls.append(f)

        return download_urls
    except Exception as e:
        print(f"  API error: {e}")
        return None


def organize_largetkga(download_dir, output_dir):
    """
    Organize downloaded LargeTKGA files into ELsEA directory structure.

    Expected source structure (after extraction):
      download_dir/
        TimeD1M/
          en_fr/
            en_triple_rel.txt
            fr_triple_rel.txt
            ...
          en_de/
            ...
        TimeFB2M/
          fb_dbp/
            ...
    """
    print("\nOrganizing dataset files...")

    for dataset_name, info in DATASET_INFO.items():
        hf_path = info['hf_path']
        source_path = os.path.join(download_dir, hf_path)

        if not os.path.exists(source_path):
            print(f"  Warning: Source path not found: {source_path}")
            continue

        kgids = info['kgids']
        kgid1, kgid2 = kgids

        # Determine output path
        if 'TimeD1M' in hf_path:
            output_path = os.path.join(output_dir, '1m_temporal', f'{kgids[0]}_{kgids[1]}')
        else:
            output_path = os.path.join(output_dir, '2m_temporal', f'{kgids[0]}_{kgids[1]}')

        os.makedirs(output_path, exist_ok=True)

        # Map source files to expected names
        # Source: en_triple_rel.txt -> {kgid1}_triple_rel.txt
        # Source: time_id.txt -> time_id.txt
        file_mappings = {
            f'{kgid1}_triple_rel.txt': f'{kgid1}_triple_rel.txt',
            f'{kgid2}_triple_rel.txt': f'{kgid2}_triple_rel.txt',
            f'{kgid1}_entity_id2uri.txt': f'{kgid1}_entity_id2uri.txt',
            f'{kgid2}_entity_id2uri.txt': f'{kgid2}_entity_id2uri.txt',
            f'{kgid1}_relation_id2uri.txt': f'{kgid1}_relation_id2uri.txt',
            f'{kgid2}_relation_id2uri.txt': f'{kgid2}_relation_id2uri.txt',
            'alignment_of_entity.txt': 'alignment_of_entity.txt',
            'time_id.txt': 'time_id.txt',
        }

        for src_name, dst_name in file_mappings.items():
            src_file = os.path.join(source_path, src_name)
            dst_file = os.path.join(output_path, dst_name)
            if os.path.exists(src_file) and not os.path.exists(dst_file):
                import shutil
                shutil.copy2(src_file, dst_file)
                print(f"  Copied {src_name} -> {output_path}")

        print(f"  {dataset_name}: organized at {output_path}")

    # Write dataset config
    config_path = os.path.join(output_dir, 'largetkga_config.json')
    config = {
        'source': HF_DATASET_ID,
        'password': PASSWORD,
        'datasets': {}
    }
    for name, info in DATASET_INFO.items():
        config['datasets'][name] = {
            'description': info['description'],
            'temporal': info['temporal'],
            'kgids': list(info['kgids']),
            'time_granularity': info.get('time_granularity', 'auto'),
        }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    print(f"\n  Config saved to: {config_path}")


def main():
    parser = argparse.ArgumentParser(
        description='Download and prepare LargeTKGA dataset from HuggingFace')
    parser.add_argument('--output_dir', type=str,
                        default='../data',
                        help='Output directory for datasets')
    parser.add_argument('--cache_dir', type=str,
                        default=None,
                        help='Cache directory for HuggingFace downloads')
    parser.add_argument('--skip_extract', action='store_true',
                        help='Skip extraction (assume files already extracted)')
    parser.add_argument('--hf_token', type=str, default=None,
                        help='HuggingFace API token (if needed)')

    args = parser.parse_args()

    output_dir = os.path.abspath(args.output_dir)
    cache_dir = os.path.abspath(args.cache_dir) if args.cache_dir else None

    print("=" * 60)
    print("LargeTKGA Dataset Downloader")
    print("=" * 60)
    print(f"Dataset: {HF_DATASET_ID}")
    print(f"Password: {PASSWORD}")
    print(f"Output: {output_dir}")
    print("=" * 60)

    # Try multiple download methods
    downloaded_path = None

    # Method 1: huggingface_hub Python
    if not downloaded_path:
        print("\n[Method 1] Trying huggingface_hub...")
        downloaded_path = try_download_with_hf()

    # Method 2: hf CLI
    if not downloaded_path:
        print("\n[Method 2] Trying hf CLI...")
        downloaded_path = try_download_with_hf_cli()

    # Method 3: Direct API
    if not downloaded_path:
        print("\n[Method 3] Trying HuggingFace API...")
        download_urls = download_via_api()
        if download_urls:
            print(f"  Found {len(download_urls)} files to download")
            # Download each file
            import requests
            os.makedirs(os.path.join(output_dir, 'largetkga_raw'), exist_ok=True)
            for url_info in download_urls:
                if isinstance(url_info, dict):
                    url = url_info.get('download')
                    filename = url_info.get('path', '').split('/')[-1]
                else:
                    url = url_info
                    filename = str(url_info).split('/')[-1]
                if url and filename:
                    out_path = os.path.join(output_dir, 'largetkga_raw', filename)
                    if not os.path.exists(out_path):
                        print(f"  Downloading {filename}...")
                        try:
                            r = requests.get(url, timeout=60, stream=True)
                            if r.status_code == 200:
                                with open(out_path, 'wb') as f:
                                    for chunk in r.iter_content(8192):
                                        f.write(chunk)
                        except Exception as e:
                            print(f"  Failed: {e}")
            downloaded_path = os.path.join(output_dir, 'largetkga_raw')

    if not downloaded_path or not os.path.exists(downloaded_path):
        print("\n" + "=" * 60)
        print("ERROR: Could not download from HuggingFace.")
        print("Please download manually from:")
        print(f"  https://huggingface.co/datasets/{HF_DATASET_ID}")
        print(f"  Password: {PASSWORD}")
        print(f"\nThen extract to: {output_dir}")
        print("=" * 60)
        sys.exit(1)

    # Organize files
    print(f"\nDownload complete! Path: {downloaded_path}")
    organize_largetkga(downloaded_path, output_dir)

    print("\n" + "=" * 60)
    print("Download complete!")
    print("\nNext steps:")
    print("  1. Convert to ELsEA format:")
    print("     python -c \"from divea.divea.convert_largetkga_to_hydra import *; from divea.divea.convert_to_hydra import *\"")
    print("  2. Run large-scale experiments:")
    print("     python run_large_scale.py --dataset TimeD1M/EN-DE --ea_model hydra")
    print("=" * 60)


if __name__ == '__main__':
    main()
