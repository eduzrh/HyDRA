# Large-Scale Entity Alignment Preprocessing

This directory contains the preprocessing pipeline for **large-scale temporal knowledge graph alignment**, following the [ELsEA framework](https://www.computer.org/csdl/proceedings-article/icde/2025/360300c227/26FZAKCH0Os) (ICDE 2025).

Place datasets in the designated directory before running.

## Supported Datasets

| Dataset | KG Pair |
|---------|---------|
| **TimeD1M/EN-FR** | DBpedia EN-FR |
| **TimeD1M/EN-DE** | DBpedia EN-DE |
| **Time-FB2M** | Freebase-DBpedia |
| **DBP1M/EN-FR** | DBpedia EN-FR |
| **DBP1M/EN-DE** | DBpedia EN-DE |
| **FBDBP2M** | Freebase-DBpedia |

## Quick Start

```bash
# Run ElSEA + DivEA partitioning with HyDRA
python run_large_scale.py --dataset TimeD1M/EN-DE --ea_model hydra
```

## Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--dataset` | Required | Dataset name (see Supported Datasets) |
| `--ea_model` | hydra | EA model |
| `--max_iteration` | 5 | Max refinement iterations |
| `--subtask_num` | 100/200 | Number of partitions |
| `--gpu_ids` | 0,1,2,3 | GPU devices |

## Citation

```bibtex
@inproceedings{ELsEA,
  title={Enhancing Large-scale Entity Alignment with Critical Structure and High-quality Context},
  author={Qian Zhou, Wei Chen, Li Zhang, Pengpeng Zhao, Jiajie Xu, Lei Zhao},
  booktitle={ICDE},
  year={2025}
}
```
