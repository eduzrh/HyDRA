# -*- coding: utf-8 -*-
"""
Data format converter: ELsEA partition format -> HyDRA format

Supports both non-temporal (3-col) and temporal (5-col) formats.

Mapping chain for entity names:
  partition_local_id -> ent_ids_1 -> global_id -> global entity_id2uri.txt -> DBpedia URI -> name

Supports ent_ids files in two formats:
  Format A: (partition_id, global_id)  - integer global ID
  Format B: (partition_id, URI)        - DBpedia/Freebase URI (from Client for temporal)

Temporal support:
  - Non-temporal: 3-col triples -> 5-col with (h, r, t, 0, 0)
  - Temporal: 5-col triples -> preserved with time string -> time ID mapping
  - time_id.txt must exist for temporal datasets
"""

import os
import re
import json
import shutil


def uri_to_name(uri):
    """Extract readable entity name from DBpedia URI."""
    match = re.search(r'/resource/(.+)$', uri)
    if not match:
        return uri
    name = match.group(1)
    name = name.replace('_', ' ')
    name = re.sub(r'%([0-9A-Fa-f]{2})', lambda m: chr(int(m.group(1), 16)), name)
    return name


def read_tab_lines(fn, encoding='utf-8'):
    if not os.path.exists(fn):
        return []
    with open(fn, 'r', encoding=encoding) as f:
        cont = f.read().strip()
        if cont == '':
            return []
        return [tuple(line.split('\t')) for line in cont.split('\n')]


def write_tab_lines(tuple_list, fn, encoding='utf-8'):
    os.makedirs(os.path.dirname(fn) or '.', exist_ok=True)
    with open(fn, 'w', encoding=encoding) as f:
        for tup in tuple_list:
            f.write('\t'.join(str(e) for e in tup) + '\n')


def _find_global_id_by_uri(uri, uri_to_gid):
    """Look up the global integer ID for a given URI using a pre-built reverse map."""
    return uri_to_gid.get(uri)


def _load_uri_to_id_map(global_fn):
    """Build a reverse map from URI -> global ID for fast lookup."""
    uri_to_id = {}
    if global_fn and os.path.exists(global_fn):
        for line in read_tab_lines(global_fn):
            if len(line) >= 2:
                try:
                    gid = int(line[0])
                    uri = line[1].strip()
                    if uri not in uri_to_id:
                        uri_to_id[uri] = gid
                except (ValueError, TypeError):
                    pass
    return uri_to_id


def _load_time_map(time_id_file):
    """Load time_id.txt into a dict {time_string: time_id}."""
    time_map = {}
    if time_id_file and os.path.exists(time_id_file):
        for line in read_tab_lines(time_id_file):
            if len(line) >= 2:
                time_map[line[1]] = int(line[0])
    return time_map


def convert_uniform_to_hydra(data_dir, kgids, global_data_dir=None,
                             preserve_temporal=True, time_id_file=None):
    """
    Convert partition data from ELsEA format to HyDRA format.

    Supports both temporal and non-temporal datasets:
      - Temporal: 5-col triples with time strings -> time IDs
      - Non-temporal: 3-col triples become (h, r, t, 0, 0)

    Args:
        data_dir: Partition data directory
        kgids: (kgid1, kgid2) tuple
        global_data_dir: Global data directory (for entity name lookup)
        preserve_temporal: If True, preserve time info from 5-col triples
        time_id_file: Optional path to time_id.txt for time string->id mapping
    """
    triples_1_path = os.path.join(data_dir, 'triples_1')
    triples_2_path = os.path.join(data_dir, 'triples_2')

    if global_data_dir is None:
        global_data_dir = os.path.dirname(data_dir)

    kgid1, kgid2 = kgids
    global_fn_1 = os.path.join(global_data_dir, f'{kgid1}_entity_id2uri.txt')
    global_fn_2 = os.path.join(global_data_dir, f'{kgid2}_entity_id2uri.txt')

    # Load time mapping if available
    if time_id_file is None:
        time_id_file = os.path.join(global_data_dir, 'time_id.txt')
    time_map = _load_time_map(time_id_file)

    # Check if already in HyDRA format (5-col with numeric time IDs)
    if os.path.exists(triples_1_path):
        sample = read_tab_lines(triples_1_path)
        if sample and len(sample[0]) >= 5:
            has_temporal = len(sample[0]) >= 5 and sample[0][3] not in ('0', 0, '')
            # Check if time is already numeric (time IDs) vs still a time string
            if has_temporal:
                try:
                    int(sample[0][3])  # Try to parse as integer
                    time_is_numeric = True
                except (ValueError, TypeError):
                    time_is_numeric = False
            else:
                time_is_numeric = True  # non-temporal is always fine

            if time_is_numeric:
                ent1_n = len(read_tab_lines(os.path.join(data_dir, 'ent_ids_1')))
                ent2_n = len(read_tab_lines(os.path.join(data_dir, 'ent_ids_2')))
                sup_n = len(read_tab_lines(os.path.join(data_dir, 'sup_pairs'))) \
                    if os.path.exists(os.path.join(data_dir, 'sup_pairs')) else 0
                ref_n = len(read_tab_lines(os.path.join(data_dir, 'ref_ent_ids'))) \
                    if os.path.exists(os.path.join(data_dir, 'ref_ent_ids')) else 0
                print(f'  Already in HyDRA format (time IDs), skipping conversion')
                return {'n_ent1': ent1_n, 'n_ent2': ent2_n,
                        'n_triples_1': len(sample),
                        'n_triples_2': len(read_tab_lines(triples_2_path)),
                        'n_train': sup_n, 'n_test': ref_n,
                        'temporal': has_temporal}
            # else: time strings still present, need to convert

    # Load existing triples (may be 3-col or 5-col)
    triples_1_raw = read_tab_lines(triples_1_path)
    triples_2_raw = read_tab_lines(triples_2_path)

    # Check if we have temporal triples (5-col with non-zero time)
    has_temporal = False
    for t in triples_1_raw:
        if len(t) >= 5 and t[3].strip() not in ('0', '', 'N/A'):
            has_temporal = True; break
    if not has_temporal:
        for t in triples_2_raw:
            if len(t) >= 5 and t[3].strip() not in ('0', '', 'N/A'):
                has_temporal = True; break

    # Load global entity->URI maps AND reverse URI->ID maps
    global_to_uri_1 = {}
    uri_to_id_1 = {}
    if os.path.exists(global_fn_1):
        for line in read_tab_lines(global_fn_1):
            if len(line) >= 2:
                try:
                    gid = int(line[0])
                    uri = line[1].strip()
                    global_to_uri_1[gid] = uri
                    if uri not in uri_to_id_1:
                        uri_to_id_1[uri] = gid
                except (ValueError, TypeError):
                    pass

    global_to_uri_2 = {}
    uri_to_id_2 = {}
    if os.path.exists(global_fn_2):
        for line in read_tab_lines(global_fn_2):
            if len(line) >= 2:
                try:
                    gid = int(line[0])
                    uri = line[1].strip()
                    global_to_uri_2[gid] = uri
                    if uri not in uri_to_id_2:
                        uri_to_id_2[uri] = gid
                except (ValueError, TypeError):
                    pass

    # Step 1: partition_local_id -> global_id (from ent_ids_1)
    # Support Format A: (partition_id, global_id) and Format B: (partition_id, URI)
    part_to_global_1 = {}
    for line in read_tab_lines(os.path.join(data_dir, 'ent_ids_1')):
        if len(line) >= 2:
            try:
                part_to_global_1[int(line[0])] = int(line[1])
            except (ValueError, TypeError):
                # Format B: URI, look up global ID via reverse map
                gid = _find_global_id_by_uri(line[1].strip(), uri_to_id_1)
                if gid is not None:
                    part_to_global_1[int(line[0])] = gid

    part_to_global_2 = {}
    for line in read_tab_lines(os.path.join(data_dir, 'ent_ids_2')):
        if len(line) >= 2:
            try:
                part_to_global_2[int(line[0])] = int(line[1])
            except (ValueError, TypeError):
                gid = _find_global_id_by_uri(line[1].strip(), uri_to_id_2)
                if gid is not None:
                    part_to_global_2[int(line[0])] = gid

    # Step 3: Build entity name map
    def build_name_map(part_to_global, global_to_uri, kgid):
        name_map = {}
        for part_id, global_id in part_to_global.items():
            if global_id is None:
                continue
            uri = global_to_uri.get(global_id)
            if uri:
                name_map[part_id] = uri_to_name(uri)
            else:
                name_map[part_id] = f'{kgid}_entity_{global_id}'
        return name_map

    ent1_name_map = build_name_map(part_to_global_1, global_to_uri_1, kgid1)
    ent2_name_map = build_name_map(part_to_global_2, global_to_uri_2, kgid2)

    # Step 4: Re-index to 0-based contiguous
    all_ent1_ids = sorted(part_to_global_1.keys())
    all_ent2_ids = sorted(part_to_global_2.keys())

    ent1_old2new = {old: new for new, old in enumerate(all_ent1_ids)}
    ent2_old2new = {old: new for new, old in enumerate(all_ent2_ids)}

    # Step 5: Convert triples (handle both 3-col and 5-col)
    def convert_triple(triple, ent_old2new, preserve_temporal, has_temporal):
        """Convert a triple from partition format to HyDRA 5-col format."""
        if len(triple) >= 5 and preserve_temporal and has_temporal:
            # 5-col: preserve time info
            h = int(triple[0])
            r = int(triple[1])
            t_tail = int(triple[2])
            t_start_str = triple[3].strip()
            t_end_str = triple[4].strip() if len(triple) > 4 else t_start_str
            # Try to convert time string to time ID using time_map
            try:
                t_start = time_map.get(t_start_str, int(t_start_str))
            except (ValueError, TypeError):
                t_start = time_map.get(t_start_str, 0)
            try:
                t_end = time_map.get(t_end_str, int(t_end_str))
            except (ValueError, TypeError):
                t_end = time_map.get(t_end_str, t_start)
            if h in ent_old2new and t_tail in ent_old2new:
                return (ent_old2new[h], r, ent_old2new[t_tail], t_start, t_end)
        else:
            # 3-col or non-temporal: add (0, 0) time columns
            if len(triple) >= 3:
                h = int(triple[0])
                r = int(triple[1])
                t_tail = int(triple[2])
                if h in ent_old2new and t_tail in ent_old2new:
                    return (ent_old2new[h], r, ent_old2new[t_tail], 0, 0)
        return None

    new_triples_1 = []
    for t in triples_1_raw:
        converted = convert_triple(t, ent1_old2new, preserve_temporal, has_temporal)
        if converted:
            new_triples_1.append(converted)

    new_triples_2 = []
    for t in triples_2_raw:
        converted = convert_triple(t, ent2_old2new, preserve_temporal, has_temporal)
        if converted:
            new_triples_2.append(converted)

    # Step 6: Convert alignment pairs
    def _load_alignment(fn_list):
        for fn in fn_list:
            fpath = os.path.join(data_dir, fn)
            if not os.path.exists(fpath):
                continue
            pairs = []
            for line in read_tab_lines(fpath):
                if len(line) >= 2:
                    e1, e2 = int(line[0]), int(line[1])
                    if e1 in ent1_old2new and e2 in ent2_old2new:
                        pairs.append((ent1_old2new[e1], ent2_old2new[e2]))
            if pairs:
                return pairs, fn
        return [], None

    sup_pairs, used_train = _load_alignment([
        'train_alignment.txt',
        'ref_ent_ids_train',
    ])

    ref_ent_ids, used_test = _load_alignment([
        'test_alignment.txt',
        'ref_ent_ids_test',
    ])

    if used_train:
        print(f'  Train pairs from: {used_train}')
    if used_test:
        print(f'  Test pairs from: {used_test}')

    # Step 7: Write HyDRA format files
    ent_ids_1 = [(ent1_old2new[pid], ent1_name_map.get(pid, f'{kgid1}_{pid}'))
                 for pid in all_ent1_ids if pid in ent1_name_map or pid in ent1_old2new]
    ent_ids_2 = [(ent2_old2new[pid], ent2_name_map.get(pid, f'{kgid2}_{pid}'))
                 for pid in all_ent2_ids if pid in ent2_name_map or pid in ent2_old2new]

    write_tab_lines(new_triples_1, os.path.join(data_dir, 'triples_1'))
    write_tab_lines(new_triples_2, os.path.join(data_dir, 'triples_2'))
    write_tab_lines(ent_ids_1, os.path.join(data_dir, 'ent_ids_1'))
    write_tab_lines(ent_ids_2, os.path.join(data_dir, 'ent_ids_2'))
    write_tab_lines(sup_pairs, os.path.join(data_dir, 'sup_pairs'))
    if ref_ent_ids:
        write_tab_lines(ref_ent_ids, os.path.join(data_dir, 'ref_ent_ids'))

    # Backup originals
    backup_dir = os.path.join(data_dir, 'elsEA_backup')
    os.makedirs(backup_dir, exist_ok=True)
    for fn in ['triples_1', 'triples_2', 'ent_ids_1', 'ent_ids_2']:
        orig_fn = os.path.join(backup_dir, fn + '.elsEA')
        if not os.path.exists(orig_fn):
            src_fn = os.path.join(data_dir, fn)
            if os.path.exists(src_fn):
                shutil.copy2(src_fn, orig_fn)

    print(f'  Converted: {len(new_triples_1)} t1, {len(new_triples_2)} t2, '
          f'{len(sup_pairs)} train, {len(ref_ent_ids)} test')
    print(f'  Temporal: {has_temporal}')

    return {
        'n_ent1': len(all_ent1_ids),
        'n_ent2': len(all_ent2_ids),
        'n_triples_1': len(new_triples_1),
        'n_triples_2': len(new_triples_2),
        'n_train': len(sup_pairs),
        'n_test': len(ref_ent_ids),
        'temporal': has_temporal,
    }
