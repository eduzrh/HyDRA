#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
End-to-end temporal data flow test.

Simulates the complete pipeline for temporal datasets:
  1. Client.generate_dataset_from_partition() writes 5-col triples
  2. convert_to_hydra.py re-indexes and preserves temporal info
  3. HyDRA format: 5-col (h, r, t, time_start_id, time_end_id)
"""

import os
import sys
import json
import shutil
import tempfile

# Add paths
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))


# ────────────────────────────────────────────────────────────────
# Minimal implementations (copied from divea/dataload.py and convert_to_hydra.py)
# to avoid torch dependency in this test
# ────────────────────────────────────────────────────────────────

def read_tab_lines(fn, encoding='utf-8'):
    if not os.path.exists(fn):
        return []
    with open(fn, 'r', encoding=encoding) as f:
        cont = f.read().strip()
        if cont == '':
            return []
        return [tuple(line.split('\t')) for line in cont.split('\n')]


def write_tab_lines(tuple_list, fn, encoding='utf-8'):
    os.makedirs(os.path.dirname(fn) or '.', exist_ok=True)
    with open(fn, 'w', encoding=encoding) as f:
        for tup in tuple_list:
            f.write('\t'.join(str(e) for e in tup) + '\n')


def _load_time_map(time_id_file):
    time_map = {}
    if time_id_file and os.path.exists(time_id_file):
        for line in read_tab_lines(time_id_file):
            if len(line) >= 2:
                time_map[line[1]] = int(line[0])
    return time_map


def convert_uniform_to_hydra(data_dir, kgids, global_data_dir=None,
                             preserve_temporal=True, time_id_file=None):
    """Copy of convert_to_hydra logic for testing."""
    triples_1_path = os.path.join(data_dir, 'triples_1')
    triples_2_path = os.path.join(data_dir, 'triples_2')

    if os.path.exists(triples_1_path):
        sample = read_tab_lines(triples_1_path)
        if sample and len(sample[0]) >= 5:
            ent1_n = len(read_tab_lines(os.path.join(data_dir, 'ent_ids_1')))
            ent2_n = len(read_tab_lines(os.path.join(data_dir, 'ent_ids_2')))
            sup_n = len(read_tab_lines(os.path.join(data_dir, 'sup_pairs'))) \
                if os.path.exists(os.path.join(data_dir, 'sup_pairs')) else 0
            ref_n = len(read_tab_lines(os.path.join(data_dir, 'ref_ent_ids'))) \
                if os.path.exists(os.path.join(data_dir, 'ref_ent_ids')) else 0
            has_temporal = len(sample[0]) >= 5 and sample[0][3] not in ('0', 0, '')
            print('  Already in HyDRA format, skipping')
            return {'n_ent1': ent1_n, 'n_ent2': ent2_n,
                    'n_triples_1': len(sample),
                    'n_triples_2': len(read_tab_lines(triples_2_path)),
                    'n_train': sup_n, 'n_test': ref_n,
                    'temporal': has_temporal}

    if global_data_dir is None:
        global_data_dir = os.path.dirname(data_dir)

    kgid1, kgid2 = kgids
    if time_id_file is None:
        time_id_file = os.path.join(global_data_dir, 'time_id.txt')
    time_map = _load_time_map(time_id_file)

    triples_1_raw = read_tab_lines(triples_1_path)
    triples_2_raw = read_tab_lines(triples_2_path)

    has_temporal = False
    for t in triples_1_raw:
        if len(t) >= 5 and t[3].strip() not in ('0', '', 'N/A'):
            has_temporal = True; break
    if not has_temporal:
        for t in triples_2_raw:
            if len(t) >= 5 and t[3].strip() not in ('0', '', 'N/A'):
                has_temporal = True; break

    part_to_global_1 = {}
    for line in read_tab_lines(os.path.join(data_dir, 'ent_ids_1')):
        if len(line) >= 2:
            part_to_global_1[int(line[0])] = int(line[1])
    part_to_global_2 = {}
    for line in read_tab_lines(os.path.join(data_dir, 'ent_ids_2')):
        if len(line) >= 2:
            part_to_global_2[int(line[0])] = int(line[1])

    global_to_uri_1 = {}
    global_fn_1 = os.path.join(global_data_dir, f'{kgid1}_entity_id2uri.txt')
    if os.path.exists(global_fn_1):
        for line in read_tab_lines(global_fn_1):
            if len(line) >= 2:
                global_to_uri_1[int(line[0])] = line[1]
    global_to_uri_2 = {}
    global_fn_2 = os.path.join(global_data_dir, f'{kgid2}_entity_id2uri.txt')
    if os.path.exists(global_fn_2):
        for line in read_tab_lines(global_fn_2):
            if len(line) >= 2:
                global_to_uri_2[int(line[0])] = line[1]

    def uri_to_name(uri):
        import re
        m = re.search(r'/resource/(.+)$', uri)
        if not m: return uri
        name = m.group(1).replace('_', ' ')
        name = re.sub(r'%([0-9A-Fa-f]{2})', lambda x: chr(int(x.group(1), 16)), name)
        return name

    def build_name_map(part_to_global, global_to_uri, kgid):
        nm = {}
        for pid, gid in part_to_global.items():
            uri = global_to_uri.get(gid)
            nm[pid] = uri_to_name(uri) if uri else f'{kgid}_entity_{gid}'
        return nm

    ent1_name_map = build_name_map(part_to_global_1, global_to_uri_1, kgid1)
    ent2_name_map = build_name_map(part_to_global_2, global_to_uri_2, kgid2)

    all_ent1_ids = sorted(part_to_global_1.keys())
    all_ent2_ids = sorted(part_to_global_2.keys())
    ent1_old2new = {old: new for new, old in enumerate(all_ent1_ids)}
    ent2_old2new = {old: new for new, old in enumerate(all_ent2_ids)}

    def convert_triple(triple, ent_old2new, preserve_temporal, has_temporal):
        if len(triple) >= 5 and preserve_temporal and has_temporal:
            h = int(triple[0]); r = int(triple[1]); t_tail = int(triple[2])
            t_start_str = triple[3].strip()
            t_end_str = triple[4].strip() if len(triple) > 4 else t_start_str
            t_start = time_map.get(t_start_str, int(t_start_str) if t_start_str not in ('0', '', 'N/A') else 0)
            t_end = time_map.get(t_end_str, int(t_end_str) if t_end_str not in ('0', '', 'N/A') else t_start)
            if h in ent_old2new and t_tail in ent_old2new:
                return (ent_old2new[h], r, ent_old2new[t_tail], t_start, t_end)
        else:
            if len(triple) >= 3:
                h = int(triple[0]); r = int(triple[1]); t_tail = int(triple[2])
                if h in ent_old2new and t_tail in ent_old2new:
                    return (ent_old2new[h], r, ent_old2new[t_tail], 0, 0)
        return None

    new_triples_1 = [c for t in triples_1_raw for c in [convert_triple(t, ent1_old2new, preserve_temporal, has_temporal)] if c]
    new_triples_2 = [c for t in triples_2_raw for c in [convert_triple(t, ent2_old2new, preserve_temporal, has_temporal)] if c]

    def _load_alignment(fn_list):
        for fn in fn_list:
            fpath = os.path.join(data_dir, fn)
            if not os.path.exists(fpath): continue
            pairs = [(int(l[0]), int(l[1])) for l in read_tab_lines(fpath) if len(l) >= 2 and int(l[0]) in ent1_old2new and int(l[1]) in ent2_old2new]
            pairs = [(ent1_old2new[e1], ent2_old2new[e2]) for e1, e2 in pairs]
            if pairs: return pairs, fn
        return [], None

    sup_pairs, _ = _load_alignment(['train_alignment.txt', 'ref_ent_ids_train'])
    ref_ent_ids, _ = _load_alignment(['test_alignment.txt', 'ref_ent_ids_test'])

    ent_ids_1 = [(ent1_old2new[pid], ent1_name_map.get(pid, f'{kgid1}_{pid}')) for pid in all_ent1_ids]
    ent_ids_2 = [(ent2_old2new[pid], ent2_name_map.get(pid, f'{kgid2}_{pid}')) for pid in all_ent2_ids]

    write_tab_lines(new_triples_1, os.path.join(data_dir, 'triples_1'))
    write_tab_lines(new_triples_2, os.path.join(data_dir, 'triples_2'))
    write_tab_lines(ent_ids_1, os.path.join(data_dir, 'ent_ids_1'))
    write_tab_lines(ent_ids_2, os.path.join(data_dir, 'ent_ids_2'))
    write_tab_lines(sup_pairs, os.path.join(data_dir, 'sup_pairs'))
    if ref_ent_ids:
        write_tab_lines(ref_ent_ids, os.path.join(data_dir, 'ref_ent_ids'))

    print(f'  Converted: {len(new_triples_1)} t1, {len(new_triples_2)} t2, {len(sup_pairs)} train, {len(ref_ent_ids)} test')
    print(f'  Temporal: {has_temporal}')
    return {
        'n_ent1': len(all_ent1_ids), 'n_ent2': len(all_ent2_ids),
        'n_triples_1': len(new_triples_1), 'n_triples_2': len(new_triples_2),
        'n_train': len(sup_pairs), 'n_test': len(ref_ent_ids),
        'temporal': has_temporal,
    }


# ────────────────────────────────────────────────────────────────
# Mock data creation
# ────────────────────────────────────────────────────────────────

def create_mock_temporal_data(tmpdir):
    """Create mock temporal dataset in LargeTKGA format: h, t, r, time_start, time_end."""
    kgid1, kgid2 = 'en', 'de'

    # Global 5-col triples (h, t, r, time_start, time_end)
    en_triples = [
        ('0', '1', '10', '1996-01', '1996-01'),
        ('0', '2', '5',  '1997-03', '1997-03'),
        ('1', '3', '2',  '1998-06', '1998-06'),
        ('3', '1', '4',  '1999-12', '1999-12'),
        ('5', '2', '3',  '2000-01', '2000-01'),
    ]
    de_triples = [
        ('0', '1', '10', '1996-01', '1996-01'),
        ('0', '2', '5',  '1997-03', '1997-03'),
        ('1', '3', '2',  '1998-06', '1998-06'),
        ('3', '1', '4',  '1999-12', '1999-12'),
        ('5', '2', '3',  '2000-01', '2000-01'),
    ]
    en_entities = [(str(i), f'http://dbpedia.org/resource/TestEntity{i}') for i in range(6)]
    de_entities = [(str(i), f'http://de.dbpedia.org/resource/TestEntitaet{i}') for i in range(6)]
    en_rels = [('0', 'type'), ('1', 'bornIn'), ('2', 'workedAt'), ('3', 'locatedIn'), ('4', 'marriedTo'), ('5', 'studiedAt')]
    de_rels = [('0', 'Typ'), ('1', 'geborenIn'), ('2', 'arbeiteteIn'), ('3', 'befindetSichIn'), ('4', 'verheiratetMit'), ('5', 'studierteAn')]
    alignment = [('0', '0'), ('1', '1'), ('3', '3')]
    train = [('0', '0')]
    test = [('1', '1'), ('3', '3')]

    write_tab_lines(en_triples, os.path.join(tmpdir, f'{kgid1}_triple_rel.txt'))
    write_tab_lines(de_triples, os.path.join(tmpdir, f'{kgid2}_triple_rel.txt'))
    write_tab_lines(en_entities, os.path.join(tmpdir, f'{kgid1}_entity_id2uri.txt'))
    write_tab_lines(de_entities, os.path.join(tmpdir, f'{kgid2}_entity_id2uri.txt'))
    write_tab_lines(en_rels, os.path.join(tmpdir, f'{kgid1}_relation_id2uri.txt'))
    write_tab_lines(de_rels, os.path.join(tmpdir, f'{kgid2}_relation_id2uri.txt'))
    write_tab_lines(alignment, os.path.join(tmpdir, 'alignment_of_entity.txt'))
    write_tab_lines(train, os.path.join(tmpdir, 'train_alignment.txt'))
    write_tab_lines(test, os.path.join(tmpdir, 'test_alignment.txt'))

    # time_id.txt
    times = sorted(set([t[3] for t in en_triples] + [t[3] for t in de_triples]))
    write_tab_lines([(str(i), t) for i, t in enumerate(times)], os.path.join(tmpdir, 'time_id.txt'))

    return kgid1, kgid2


def create_mock_partition(tmpdir, kgid1, kgid2):
    """Create mock partition (kg_partition.json) as ELsEA would create."""
    part_dir = os.path.join(tmpdir, 'partition_1')
    os.makedirs(part_dir)
    obj = {
        'kg1_partition': {
            'entities': [0, 1, 3],
            'ctx_entities': [],
            'triples': [],  # Client reloads from global
            'alignment': [(0, 0), (1, 1), (3, 3)],
            'train_alignment': [(0, 0)],
            'test_alignment': [(1, 1), (3, 3)],
        },
        'kg2_partition': {
            'entities': [0, 1, 3],
            'ctx_entities': [],
            'triples': [],
        }
    }
    with open(os.path.join(part_dir, 'kg_partition.json'), 'w') as f:
        json.dump(obj, f)
    return part_dir


def simulate_client_write(part_dir, tmpdir, kgid1, kgid2):
    """Simulate Client.generate_dataset_from_partition() for temporal data."""
    data_dir = tmpdir
    with open(os.path.join(part_dir, 'kg_partition.json')) as f:
        obj = json.load(f)
        kg1_part_obj = obj['kg1_partition']
        kg2_part_obj = obj['kg2_partition']

    is_temporal = os.path.exists(os.path.join(data_dir, 'time_id.txt'))
    print('  [Step 1] is_temporal={}'.format(is_temporal))

    kg1_old2new = {old: new for new, old in enumerate(sorted(set(kg1_part_obj['entities'])))}
    kg2_old2new = {old: new for new, old in enumerate(sorted(kg2_part_obj['entities']))}

    write_tab_lines([(New, kgid1 + '_entity_' + str(old)) for old, New in kg1_old2new.items()],
                    os.path.join(part_dir, kgid1 + '_entity_id2uri.txt'))
    write_tab_lines([(New, kgid2 + '_entity_' + str(old)) for old, New in kg2_old2new.items()],
                    os.path.join(part_dir, kgid2 + '_entity_id2uri.txt'))

    if is_temporal:
        def load_temporal(global_file, old2new):
            triples = []
            for line in read_tab_lines(global_file):
                if len(line) < 5: continue
                h = int(line[0]); t = int(line[2]); r = int(line[1])
                t_start = line[3].strip(); t_end = line[4].strip()
                if h in old2new and t in old2new:
                    triples.append((old2new[h], r, old2new[t], t_start, t_end))
            return triples

        kg1_triples = load_temporal(os.path.join(data_dir, kgid1 + '_triple_rel.txt'), kg1_old2new)
        kg2_triples = load_temporal(os.path.join(data_dir, kgid2 + '_triple_rel.txt'), kg2_old2new)
    else:
        kg1_triples, kg2_triples = [], []

    write_tab_lines(kg1_triples, os.path.join(part_dir, kgid1 + '_triple_rel.txt'))
    write_tab_lines(kg2_triples, os.path.join(part_dir, kgid2 + '_triple_rel.txt'))

    alignment = [(kg1_old2new[e1], kg2_old2new[e2]) for e1, e2 in kg1_part_obj['alignment']
                 if e1 in kg1_old2new and e2 in kg2_old2new]
    train = [(kg1_old2new[e1], kg2_old2new[e2]) for e1, e2 in kg1_part_obj['train_alignment']
             if e1 in kg1_old2new and e2 in kg2_old2new]
    test = [(kg1_old2new[e1], kg2_old2new[e2]) for e1, e2 in kg1_part_obj['test_alignment']
            if e1 in kg1_old2new and e2 in kg2_old2new]
    write_tab_lines(alignment, os.path.join(part_dir, 'alignment_of_entity.txt'))
    write_tab_lines(train, os.path.join(part_dir, 'train_alignment.txt'))
    write_tab_lines(test, os.path.join(part_dir, 'test_alignment.txt'))

    return kg1_triples, kg2_triples


def verify_hydra_format(part_dir, kgid1, kgid2):
    """Verify HyDRA 5-col format with non-zero temporal data."""
    triples_1 = read_tab_lines(os.path.join(part_dir, 'triples_1'))
    triples_2 = read_tab_lines(os.path.join(part_dir, 'triples_2'))
    print('  [Step 3] triples_1 count={}, triples_2 count={}'.format(len(triples_1), len(triples_2)))

    all_ok = True
    for t in triples_1:
        cols = len(t)
        t_start = t[3] if cols >= 4 else 'MISSING'
        t_end = t[4] if cols >= 5 else 'MISSING'
        ok = cols >= 5 and t_start not in ('0', '', 'N/A')
        status = 'OK' if ok else 'FAIL'
        if not ok: all_ok = False
        print('  [{}] h={} r={} t={} t_start={} t_end={}'.format(
            status, t[0], t[1], t[2], t_start, t_end))
    return all_ok


def main():
    print('=' * 70)
    print('Temporal Data Flow End-to-End Test')
    print('=' * 70)

    tmpdir = tempfile.mkdtemp(prefix='hydra_temporal_test_')
    print('\nTest directory: {}'.format(tmpdir))

    try:
        # Step 0: Create mock temporal data
        print('\n[Step 0] Creating mock temporal data (LargeTKGA format: h,t,r,YYYY-MM,YYYY-MM)')
        kgid1, kgid2 = create_mock_temporal_data(tmpdir)

        print('\nGlobal {}_triple_rel.txt (5-col):'.format(kgid1))
        for line in read_tab_lines(os.path.join(tmpdir, kgid1 + '_triple_rel.txt')):
            print('  ' + '\t'.join(line))

        print('\ntime_id.txt:')
        for line in read_tab_lines(os.path.join(tmpdir, 'time_id.txt')):
            print('  ' + '\t'.join(line))

        # Step 0.5: Create partition
        print('\n[Step 0.5] Creating ELsEA partition (entities [0,1,3])')
        part_dir = create_mock_partition(tmpdir, kgid1, kgid2)

        # Step 1: Client writes temporal triples
        print('\n[Step 1] Client.generate_dataset_from_partition() writes 5-col triples')
        kg1_triples, kg2_triples = simulate_client_write(part_dir, tmpdir, kgid1, kgid2)

        print('\nAfter Client - {}_triple_rel.txt:'.format(kgid1))
        for line in read_tab_lines(os.path.join(part_dir, kgid1 + '_triple_rel.txt')):
            print('  ' + '\t'.join(line))

        # Step 2: convert_to_hydra
        print('\n[Step 2] convert_to_hydra() re-indexes and maps time strings -> time_ids')
        stats = convert_uniform_to_hydra(
            part_dir, (kgid1, kgid2),
            global_data_dir=tmpdir,
            preserve_temporal=True,
            time_id_file=os.path.join(tmpdir, 'time_id.txt')
        )
        print('  Stats: {}'.format(stats))
        print('  temporal flag: {}'.format(stats.get('temporal', False)))

        # Step 3: Verify HyDRA format
        print('\n[Step 3] Verifying HyDRA 5-col format')
        ok = verify_hydra_format(part_dir, kgid1, kgid2)

        print('\n' + '=' * 70)
        if ok:
            print('RESULT: PASS')
            print('  Source:  h\tt\tr\t1996-01\t1996-01  (LargeTKGA format)')
            print('       -> Client: writes 5-col (h, r, t, time_str, time_str)')
            print('       -> convert_to_hydra: re-index + time string -> time_id mapping')
            print('       -> HyDRA: h\tr\tt\ttime_id_start\ttime_id_end')
            print('  Temporal info CORRECTLY preserved through entire pipeline!')
        else:
            print('RESULT: FAIL - Temporal data lost or corrupted')
        print('=' * 70)
        return 0 if ok else 1

    finally:
        shutil.rmtree(tmpdir)
        print('\nCleaned up test directory')


if __name__ == '__main__':
    sys.exit(main())
