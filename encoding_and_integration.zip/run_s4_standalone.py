#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Standalone script to run S4 (Simple-HHEA) training
"""

import os
import sys
import subprocess
import argparse

def run_simple_hhea(data_dir, cuda=0, epochs=500):
    """
    Run Simple-HHEA training
    
    Args:
        data_dir: Data directory path (e.g., data/icews_wiki)
        cuda: CUDA device ID
        epochs: Number of training epochs
    """
    lang = os.path.basename(data_dir.rstrip('/'))
    lr = 0.01
    wd = 0.001
    gamma = 1.0
    
    # Get project root (parent directory of this script's parent, i.e., HyDRA root)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    s4_dir = os.path.join(script_dir, "s4", "Simple-HHEA")
    
    commands = [
        f"python {os.path.join(s4_dir, 'process_name_embedding.py')} --data {lang}",
        f"python {os.path.join(s4_dir, 'feature_perprocessing', 'preprocess.py')} --l {lang}",
        f"python {os.path.join(s4_dir, 'feature_perprocessing', 'longterm', 'main.py')} --input 'data/{lang}/deepwalk.data' --output 'data/{lang}/longterm.vec' --node2rel 'data/{lang}/node2rel' --q 0.7",
        f"python {os.path.join(s4_dir, 'feature_perprocessing', 'get_deep_emb.py')} --path 'data/{lang}/'",
        f"python {os.path.join(s4_dir, 'main_SimpleHHEA.py')} --data {lang} --cuda {cuda} --lr {lr} --wd {wd} --gamma {gamma} --epochs {epochs} --noise_ratio 0.0"
    ]
    
    try:
        # Set HuggingFace mirror environment variable
        env = os.environ.copy()
        env['HF_ENDPOINT'] = 'https://hf-mirror.com'
        
        # Change to project root directory
        original_cwd = os.getcwd()
        os.chdir(project_root)
        
        for cmd in commands:
            print(f"\nExecuting: {cmd}")
            result = subprocess.run(cmd, shell=True, check=True, text=True, env=env)
            if result.returncode != 0:
                print(f"Error executing command: {cmd}")
                os.chdir(original_cwd)
                return False
        
        os.chdir(original_cwd)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {e.cmd}")
        print(f"Error output: {e.stderr if hasattr(e, 'stderr') else 'N/A'}")
        os.chdir(original_cwd)
        return False
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        os.chdir(original_cwd)
        return False


def main():
    parser = argparse.ArgumentParser(description="Run S4 (Simple-HHEA) training")
    parser.add_argument("--data_dir", type=str, required=True, help="Data directory path (e.g., data/icews_wiki)")
    parser.add_argument("--cuda", type=int, default=0, help="CUDA device ID (default: 0)")
    parser.add_argument("--epochs", type=int, default=500, help="Number of training epochs (default: 500)")
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("S4 (Simple-HHEA) Training")
    print("=" * 80)
    print(f"Data directory: {args.data_dir}")
    print(f"CUDA device: {args.cuda}")
    print(f"Epochs: {args.epochs}")
    print("=" * 80)
    
    success = run_simple_hhea(args.data_dir, args.cuda, args.epochs)
    
    if success:
        print("\n" + "=" * 80)
        print("✓ S4 training completed successfully!")
        print("=" * 80)
        sys.exit(0)
    else:
        print("\n" + "=" * 80)
        print("✗ S4 training failed!")
        print("=" * 80)
        sys.exit(1)


if __name__ == "__main__":
    main()


