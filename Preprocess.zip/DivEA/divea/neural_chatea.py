# -*- coding: utf-8 -*-
"""ChatEA Entity Alignment - Multi-turn conversational LLM alignment."""

import os, json, re, numpy as np
from typing import List, Tuple

from divea.util import Config
from divea.llm_ea.base_llm_ea import BaseLLMEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class ChatEAModule(BaseLLMEAModule):
    method_name = "ChatEA"

    def __init__(self, conf, llm_backend=None, top_k=20, max_turns=5):
        super().__init__(conf, llm_backend)
        self.top_k = top_k
        self.max_turns = max_turns

    def _run_alignment(self, data_dir, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        ent1_ids = sorted(self._entity_texts_1.keys())
        ent2_ids = sorted(self._entity_texts_2.keys())

        ent1_names = [self._entity_texts_1[i] for i in ent1_ids]
        ent2_names = [self._entity_texts_2[i] for i in ent2_ids]
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)

        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        sim_matrix = ent1_norm @ ent2_norm.T
        top_k_indices = np.argsort(-sim_matrix, axis=1)[:, :self.top_k]

        predicted_pairs = []
        for i, e1 in enumerate(ent1_ids):
            candidates = [ent2_ids[j] for j in top_k_indices[i][:self.top_k]]
            result = self._multi_turn_match(e1, candidates)
            if result is not None:
                predicted_pairs.append((e1, result))

        print("[ChatEA] Predicted {} pairs".format(len(predicted_pairs)))
        with open(os.path.join(output_dir, "chatea_predictions.json"), "w") as f:
            json.dump({"pairs": predicted_pairs}, f)
        return predicted_pairs

    def _multi_turn_match(self, e1, candidates):
        name1 = self._entity_texts_1.get(e1, "E{}".format(e1))
        neighbors1 = self._get_neighbor_texts(e1, kg=1)

        candidate_descriptions = []
        for e2 in candidates:
            name2 = self._entity_texts_2.get(e2, "E{}".format(e2))
            neighbors2 = self._get_neighbor_texts(e2, kg=2)
            candidate_descriptions.append("[{}] {} | connections: {}".format(e2, name2, neighbors2))

        conversation = [
            ("system", "You are an entity alignment assistant. Find the matching entity through conversation. Ask clarifying questions if needed, then give your final answer."),
        ]
        conversation.append(("user",
            "I need to find the matching entity for: \"{}\"\nIts connections: {}\n\nCandidates:\n{}\n\nPlease help me match. Start by analyzing what you see.".format(
                name1, neighbors1, "\n".join(candidate_descriptions))))

        for turn in range(self.max_turns):
            history = self._format_conversation(conversation)
            response = self.llm.generate(history, temperature=0.2, max_tokens=512)
            conversation.append(("assistant", response))

            result = self._extract_final_answer(response, candidates)
            if result is not None:
                return result

            if turn < self.max_turns - 1:
                conversation.append(("user", "Can you narrow it down further? Which single candidate do you choose?"))

        conversation.append(("user", "Please give your final answer now: just the candidate ID number, or say NONE."))
        history = self._format_conversation(conversation)
        response = self.llm.generate(history, temperature=0.0, max_tokens=128)
        result = self._extract_final_answer(response, candidates)
        return result

    def _format_conversation(self, messages):
        parts = []
        for role, content in messages:
            if role == "system":
                parts.append("System: {}".format(content))
            elif role == "user":
                parts.append("User: {}".format(content))
            else:
                parts.append("Assistant: {}".format(content))
        return "\n\n".join(parts)

    def _extract_final_answer(self, response, candidates):
        patterns = [
            r"(?:FINAL|ANSWER|final|answer)\s*:\s*(\d+)",
            r"(?:choose|candidate|select|pick|match)\s*(?:is\s*)?(?:ID\s*)?(\d+)",
            r"(?:I\s+choose|I\s+select|I\s+pick)\s*(?:ID\s*)?(\d+)",
        ]
        for pat in patterns:
            match = re.search(pat, response, re.IGNORECASE)
            if match:
                pred_id = int(match.group(1))
                if pred_id in candidates:
                    return pred_id
        if re.search(r"\b(NONE|no match|none|no candidate)\b", response, re.IGNORECASE):
            return None
        return None