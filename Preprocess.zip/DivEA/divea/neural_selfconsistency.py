# -*- coding: utf-8 -*-
"""Self-Consistency Entity Alignment - majority voting across diverse LLM predictions."""

import os, json, re, numpy as np
from typing import List, Tuple
from collections import Counter

from divea.util import Config
from divea.llm_ea.base_llm_ea import BaseLLMEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class SelfConsistencyModule(BaseLLMEAModule):
    method_name = "SelfConsistency"
    PROMPT_TEMPLATES = ["direct", "cot", "attribute", "neighbor", "crosslingual"]

    def __init__(self, conf, llm_backend=None, n_samples=5, temperature=0.7, top_k=20):
        super().__init__(conf, llm_backend)
        self.n_samples = n_samples
        self.temperature = temperature
        self.top_k = top_k

    def _run_alignment(self, data_dir, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        ent1_ids = sorted(self._entity_texts_1.keys())
        ent2_ids = sorted(self._entity_texts_2.keys())

        ent1_names = [self._entity_texts_1[i] for i in ent1_ids]
        ent2_names = [self._entity_texts_2[i] for i in ent2_ids]
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)

        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        sim_matrix = ent1_norm @ ent2_norm.T
        top_k_indices = np.argsort(-sim_matrix, axis=1)[:, :self.top_k]

        all_votes = {}
        for sample_idx in range(self.n_samples):
            template = self.PROMPT_TEMPLATES[sample_idx % len(self.PROMPT_TEMPLATES)]
            temp = self.temperature * (0.5 + 0.5 * sample_idx / max(self.n_samples, 1))
            for i, src_idx in enumerate(ent1_ids):
                candidates = [ent2_ids[j] for j in top_k_indices[i][:self.top_k]]
                best_e2 = self._predict_one(src_idx, candidates, template, temp)
                if best_e2 is not None:
                    all_votes.setdefault(src_idx, []).append(best_e2)

        predicted_pairs = []
        for e1, votes in all_votes.items():
            if len(votes) >= max(self.n_samples // 2, 1):
                counter = Counter(votes)
                most_common = counter.most_common(1)[0]
                if most_common[1] >= 2:
                    predicted_pairs.append((e1, most_common[0]))

        predicted_pairs = self._bidirectional_check(predicted_pairs, ent1_embs, ent2_embs)
        print("[SelfConsistency] Final: {} pairs".format(len(predicted_pairs)))

        with open(os.path.join(output_dir, "selfconsistency_predictions.json"), "w") as f:
            json.dump({"pairs": predicted_pairs, "n_votes": len(all_votes)}, f)
        return predicted_pairs

    def _predict_one(self, e1, candidates, template, temperature):
        name1 = self._entity_texts_1.get(e1, "E{}".format(e1))
        neighbors1 = self._get_neighbor_texts(e1, kg=1)
        candidate_texts = []
        for e2 in candidates:
            name2 = self._entity_texts_2.get(e2, "E{}".format(e2))
            neighbors2 = self._get_neighbor_texts(e2, kg=2)
            candidate_texts.append("  [{}] {} (neighbors: {})".format(e2, name2, neighbors2))
        candidates_str = "\n".join(candidate_texts)

        prompts = {
            "direct": "Entity: {}\nNeighbors: {}\n\nCandidates:\n{}\n\nWhich candidate ID matches? Reply with just the ID number, or -1.",
            "cot": "Entity: {}\nNeighbors: {}\n\nCandidates:\n{}\n\nThink step by step. Final answer: ID number or -1.",
            "attribute": "Entity: {}\nConnections: {}\n\nCandidates:\n{}\n\nBased on name and structure, which matches? ID only.",
            "neighbor": "Entity: {}\nConnected to: {}\n\nCandidates with connections:\n{}\n\nMost similar connections? ID only.",
            "crosslingual": "Entity: {} (relations: {})\n\nCandidates:\n{}\n\nCross-lingual counterpart? ID or -1.",
        }
        prompt = prompts.get(template, prompts["direct"]).format(name1, neighbors1, candidates_str)

        response = self.llm.generate(prompt,
            system_prompt="Entity alignment system. Reply with ID number only.",
            temperature=temperature, max_tokens=64)
        try:
            numbers = re.findall(r"-?\d+", response)
            if numbers:
                pred_id = int(numbers[0])
                if pred_id in candidates:
                    return pred_id
        except:
            pass
        return None

    def _bidirectional_check(self, pairs, ent1_embs, ent2_embs):
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        rev_sim = ent2_norm @ ent1_norm.T
        rev_top1 = np.argmax(rev_sim, axis=1)
        ent2_keys = sorted(self._entity_texts_2.keys())
        ent1_keys = sorted(self._entity_texts_1.keys())
        e2_to_e1 = {ent2_keys[j]: ent1_keys[i] for j, i in enumerate(rev_top1)}
        consistent = [(e1, e2) for e1, e2 in pairs if e2_to_e1.get(e2) == e1]
        dropped = len(pairs) - len(consistent)
        if dropped > 0:
            print("[SelfConsistency] Bidirectional check dropped {} pairs".format(dropped))
        return consistent