"""
Multi-Granular Temporal Encoder
Extends Simple-HHEA to support multiple temporal granularities (year, month, day, hour, etc.)
"""
import os
import numpy as np
from tqdm import tqdm
import torch
import torch.nn as nn


def extract_multi_granular_time(time_str):
    """
    Extract time at different granularities from time string
    Format: "YYYY-MM-DD" or "YYYY-MM" or "YYYY"
    """
    granularities = {}
    
    if not time_str or time_str == "~" or time_str == "00":
        return {g: 0 for g in ['year', 'month', 'day', 'hour']}
    
    try:
        # Handle negative years (e.g., "-0001-01-00" -> parts = ['', '0001', '01', '00'])
        is_negative = time_str.startswith("-")
        if is_negative:
            # Remove leading "-" and split
            time_str_clean = time_str[1:]
            parts = time_str_clean.split("-")
            if len(parts) >= 1:
                if parts[0] == "00" or parts[0] == "":
                    return {g: 0 for g in ['year', 'month', 'day', 'hour']}
                granularities['year'] = -int(parts[0])  # Negative year
        else:
        parts = time_str.split("-")
        if len(parts) >= 1:
                # Handle "00" as empty granularity
                if parts[0] == "00":
                    return {g: 0 for g in ['year', 'month', 'day', 'hour']}
            granularities['year'] = int(parts[0])
        if len(parts) >= 2:
            # Handle "00" as missing month (only year available)
            month_val = parts[1]
            if month_val == "00":
                granularities['month'] = 0  # 0 means no month information
            else:
                granularities['month'] = int(month_val)
        if len(parts) >= 3:
            day_part = parts[2].split(" ")[0] if " " in parts[2] else parts[2]
            # Handle "00" as missing day (only year and month available)
            if day_part == "00":
                granularities['day'] = 0  # 0 means no day information
            else:
            granularities['day'] = int(day_part)
            if " " in parts[2] and len(parts[2].split(" ")) > 1:
                hour_part = parts[2].split(" ")[1].split(":")[0]
                granularities['hour'] = int(hour_part)
        else:
            # If only 2 parts (YYYY-MM or YYYY-0000), day defaults to 0 (no day info)
            granularities['day'] = 0
            granularities['hour'] = 0
    except:
        return {g: 0 for g in ['year', 'month', 'day', 'hour']}
    
    # Fill missing granularities
    if 'year' not in granularities:
        granularities['year'] = 0
    if 'month' not in granularities:
        granularities['month'] = 1
    if 'day' not in granularities:
        granularities['day'] = 1
    if 'hour' not in granularities:
        granularities['hour'] = 0
    
    return granularities


def load_multi_granular_ent_time_matrix(data_path, granularities=['year', 'month', 'day']):
    """
    Load entity time matrix with multi-granular temporal information
    Returns: dict of {granularity: entity_time_matrix}
    """
    ### load entities
    ent_1_list, ent_2_list = [], []
    with open(os.path.join(data_path, "ent_ids_1"), "r", encoding="utf-8") as fr:
        for line in fr.readlines():
            if line:
                line = line.strip().split("\t")
                ent_1_list.append(int(line[0]))
    with open(os.path.join(data_path, "ent_ids_2"), "r", encoding="utf-8") as fr:
        for line in fr.readlines():
            if line:
                line = line.strip().split("\t")
                ent_2_list.append(int(line[0]))
    ent_1_num, ent_2_num = len(ent_1_list), len(ent_2_list)

    ### get id-time dictionary
    time_dict = {}
    with open(os.path.join(data_path, "time_id"), "r", encoding="utf-8") as fr:
        for line in fr.readlines():
            if line:
                line = line.strip().split("\t")
                if line[1] == "" or line[1][0] == "-":
                    line[1] = "~"
                time_dict[int(line[0])] = line[1]

    ### Initialize multi-granular time matrices
    # For each granularity, create a time span
    time_spans = {}
    min_year, max_year = 1995, 2022  # Default range, can be adjusted
    
    # Year granularity: years from min_year to max_year
    time_spans['year'] = max_year - min_year + 1
    
    # Month granularity: (max_year - min_year + 1) * 12 months
    time_spans['month'] = (max_year - min_year + 1) * 12
    
    # Day granularity: approximate days (can be refined)
    time_spans['day'] = (max_year - min_year + 1) * 365
    
    # Initialize matrices for each granularity
    ent_time_matrices = {}
    for gran in granularities:
        time_emb_size = 1 + time_spans[gran]  # +1 for "before min_year" bucket
        ent_1_emb = np.zeros([ent_1_num, time_emb_size])
        ent_2_emb = np.zeros([ent_2_num, time_emb_size])
        ent_time_matrices[gran] = (ent_1_emb, ent_2_emb, time_emb_size)

    ### Process triples_1
    with open(os.path.join(data_path, "triples_1"), "r", encoding="utf-8") as fr:
        for line in tqdm(fr.readlines(), desc="Processing KG1 triples for multi-granular time"):
            parts = line.strip().split("\t")
            if len(parts) == 5:
                h = int(parts[0])
                ts = int(parts[3])
                te = int(parts[4])
                
                for tau in [ts, te]:
                    if tau in time_dict and time_dict[tau] != "~":
                        time_str = time_dict[tau]
                        gran_dict = extract_multi_granular_time(time_str)
                        
                        # Update each granularity matrix
                        for gran in granularities:
                            if gran == 'year':
                                year_val = gran_dict['year']
                                if year_val < min_year:
                                    ent_time_matrices[gran][0][h, 0] += 1
                                elif year_val <= max_year:
                                    idx = year_val - min_year + 1
                                    if idx < ent_time_matrices[gran][2]:
                                        ent_time_matrices[gran][0][h, idx] += 1
                            elif gran == 'month':
                                year_val = gran_dict['year']
                                month_val = gran_dict['month']
                                if year_val < min_year:
                                    ent_time_matrices[gran][0][h, 0] += 1
                                elif year_val <= max_year:
                                    idx = (year_val - min_year) * 12 + month_val
                                    if idx < ent_time_matrices[gran][2]:
                                        ent_time_matrices[gran][0][h, idx] += 1
                            elif gran == 'day':
                                year_val = gran_dict['year']
                                month_val = gran_dict['month']
                                day_val = gran_dict['day']
                                if year_val < min_year:
                                    ent_time_matrices[gran][0][h, 0] += 1
                                else:
                                    # Approximate day index
                                    days_from_start = (year_val - min_year) * 365 + (month_val - 1) * 30 + day_val
                                    idx = min(days_from_start, ent_time_matrices[gran][2] - 1)
                                    ent_time_matrices[gran][0][h, idx] += 1

    ### Process triples_2
    with open(os.path.join(data_path, "triples_2"), "r", encoding="utf-8") as fr:
        for line in tqdm(fr.readlines(), desc="Processing KG2 triples for multi-granular time"):
            parts = line.strip().split("\t")
            if len(parts) == 5:
                h = int(parts[0])
                ts = int(parts[3])
                te = int(parts[4])
                
                kg2_entity_idx = h - ent_1_num
                
                # Process time range [ts, te] similar to original implementation
                if ts in time_dict and time_dict[ts] != "~":
                    time_str_start = time_dict[ts]
                    gran_dict_start = extract_multi_granular_time(time_str_start)
                    
                    if te in time_dict and time_dict[te] != "~":
                        time_str_end = time_dict[te]
                        gran_dict_end = extract_multi_granular_time(time_str_end)
                        
                        # Process time range for each granularity
                        for gran in granularities:
                            if gran == 'year':
                                year_start = gran_dict_start['year']
                                year_end = gran_dict_end['year']
                                if year_start < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                elif year_start <= max_year:
                                    for y in range(year_start, min(year_end + 1, max_year + 1)):
                                        idx = y - min_year + 1
                                        if idx < ent_time_matrices[gran][2]:
                                            ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1
                            elif gran == 'month':
                                year_start = gran_dict_start['year']
                                month_start = gran_dict_start['month']
                                year_end = gran_dict_end['year']
                                month_end = gran_dict_end['month']
                                if year_start < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                elif year_start <= max_year:
                                    # Approximate: process months in range
                                    start_idx = (year_start - min_year) * 12 + month_start
                                    end_idx = (year_end - min_year) * 12 + month_end
                                    for idx in range(start_idx, min(end_idx + 1, ent_time_matrices[gran][2])):
                                        ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1
                            elif gran == 'day':
                                year_start = gran_dict_start['year']
                                month_start = gran_dict_start['month']
                                day_start = gran_dict_start['day']
                                if year_start < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                else:
                                    days_from_start = (year_start - min_year) * 365 + (month_start - 1) * 30 + day_start
                                    idx = min(days_from_start, ent_time_matrices[gran][2] - 1)
                                    ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1
                    else:
                        # Only start time available
                        gran_dict = gran_dict_start
                        for gran in granularities:
                            if gran == 'year':
                                year_val = gran_dict['year']
                                if year_val < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                elif year_val <= max_year:
                                    idx = year_val - min_year + 1
                                    if idx < ent_time_matrices[gran][2]:
                                        ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1
                            elif gran == 'month':
                                year_val = gran_dict['year']
                                month_val = gran_dict['month']
                                if year_val < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                elif year_val <= max_year:
                                    idx = (year_val - min_year) * 12 + month_val
                                    if idx < ent_time_matrices[gran][2]:
                                        ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1
                            elif gran == 'day':
                                year_val = gran_dict['year']
                                month_val = gran_dict['month']
                                day_val = gran_dict['day']
                                if year_val < min_year:
                                    ent_time_matrices[gran][1][kg2_entity_idx, 0] += 1
                                else:
                                    days_from_start = (year_val - min_year) * 365 + (month_val - 1) * 30 + day_val
                                    idx = min(days_from_start, ent_time_matrices[gran][2] - 1)
                                    ent_time_matrices[gran][1][kg2_entity_idx, idx] += 1

    ### Combine KG1 and KG2 matrices for each granularity
    result = {}
    for gran in granularities:
        combined = np.concatenate([ent_time_matrices[gran][0], ent_time_matrices[gran][1]], axis=0)
        result[gran] = combined
    
    return result, time_spans
