"""
Multi-Granular Simple-HHEA Model
Extends Simple-HHEA to support multi-granular temporal information
"""
import numpy as np
import torch
import torch.nn as nn
from torch.nn.parameter import Parameter
from model import Time2Vec, CosineActivation


class MultiGranularTime2Vec(nn.Module):
    """
    Multi-granular Time2Vec encoder that encodes time at different granularities
    Each granularity uses a separate Time2Vec encoder, then features are fused
    """
    def __init__(self, hidden_dim=32, granularities=['year', 'month', 'day']):
        super(MultiGranularTime2Vec, self).__init__()
        self.granularities = granularities
        self.hidden_dim = hidden_dim
        
        # Create a Time2Vec encoder for each granularity
        self.encoders = nn.ModuleDict()
        for gran in granularities:
            self.encoders[gran] = Time2Vec(hidden_dim)
        
        # Fusion layer to combine multi-granular features
        self.fusion = nn.Linear(hidden_dim * len(granularities), hidden_dim)
        
    def forward(self, time_indices_dict):
        """
        Args:
            time_indices_dict: dict of {granularity: time_index_tensor}
                              Each tensor should be [time_span, 1] shape
        Returns:
            fused temporal representation [time_span, hidden_dim]
        """
        encoded_features = []
        for gran in self.granularities:
            if gran in time_indices_dict:
                # Encode time indices for this granularity
                encoded = self.encoders[gran](time_indices_dict[gran])
                encoded_features.append(encoded)
            else:
                # Zero padding if granularity not available
                if len(encoded_features) > 0:
                    encoded_features.append(torch.zeros_like(encoded_features[0]))
                else:
                    # This shouldn't happen if at least one granularity is provided
                    device = next(self.encoders.values()).parameters().__iter__().__next__().device
                    encoded_features.append(torch.zeros(1, self.hidden_dim).to(device))
        
        # Concatenate and fuse
        if len(encoded_features) > 0:
            concatenated = torch.cat(encoded_features, dim=-1)
            fused = self.fusion(concatenated)
            return fused
        else:
            device = next(self.encoders.values()).parameters().__iter__().__next__().device
            return torch.zeros(1, self.hidden_dim).to(device)


class MultiGranular_Simple_HHEA(nn.Module):
    """
    Multi-Granular Simple-HHEA Model
    Extends Simple-HHEA with multi-granular temporal encoding
    """
    def __init__(self, time_spans, ent_name_emb, ent_time_emb_dict, ent_dw_emb, 
                 use_structure=True, use_time=True, emb_size=64, structure_size=8, 
                 time_size=8, granularities=['year', 'month', 'day'], device="cuda"):
        super(MultiGranular_Simple_HHEA, self).__init__()

        self.device = device
        self.use_structure = use_structure
        self.use_time = use_time
        self.granularities = granularities

        self.emb_size = emb_size
        self.struct_size = structure_size
        self.time_size = time_size

        linear_size_1 = self.emb_size

        if self.use_time:
            linear_size_1 += self.time_size
            # Store multi-granular time embeddings
            self.ent_time_emb_dict = {}
            for gran in granularities:
                if gran in ent_time_emb_dict:
                    self.ent_time_emb_dict[gran] = torch.tensor(ent_time_emb_dict[gran]).to(self.device).float()
            
            # Multi-granular time encoder
            self.multi_granular_time2vec = MultiGranularTime2Vec(hidden_dim=32, granularities=granularities)
            
            # Time processing layers
            self.fc_time_0 = nn.Linear(32, 32)
            self.fc_time = nn.Linear(32, self.time_size)
            
            # Create time span indices for each granularity
            # Note: time_emb_size = 1 + time_span (includes index 0 for "before min_year")
            self.time_span_indices = {}
            for gran in granularities:
                if gran in time_spans:
                    time_span = time_spans[gran]
                    time_emb_size = 1 + time_span  # Include index 0
                    self.time_span_indices[gran] = torch.tensor(
                        np.array([i for i in range(time_emb_size)])
                    ).to(self.device).unsqueeze(1).float()

        if self.use_structure:
            linear_size_1 += self.struct_size
            self.ent_dw_emb = torch.tensor(ent_dw_emb).to(self.device).float()
            self.fc_dw_0 = nn.Linear(self.ent_dw_emb.shape[-1], emb_size)
            self.fc_dw = nn.Linear(emb_size, self.struct_size)
        
        self.fc_final = nn.Linear(linear_size_1, emb_size)

        self.ent_name_emb = torch.tensor(ent_name_emb).to(self.device).float()
        self.fc_name_0 = nn.Linear(self.ent_name_emb.shape[-1], emb_size)
        self.fc_name = nn.Linear(emb_size, emb_size)

        self.dropout = nn.Dropout(p=0.3)
        self.activation = nn.ReLU()

    def forward(self):
        # Name feature (same as original)
        ent_name_feature = self.fc_name(self.fc_name_0(self.dropout(self.ent_name_emb)))
        features = [ent_name_feature]

        if self.use_time:
            # Multi-granular temporal encoding
            # For each granularity: encode time indices, then compute entity-time features
            ent_time_features_list = []
            for gran in self.granularities:
                if gran in self.ent_time_emb_dict and gran in self.time_span_indices:
                    # Encode time indices for this granularity
                    time_span_indices = self.time_span_indices[gran]  # [time_span, 1]
                    time_span_feature = self.multi_granular_time2vec.encoders[gran](time_span_indices)  # [time_span, hidden_dim]
                    
                    # Compute entity-time feature for this granularity
                    ent_time_emb = self.ent_time_emb_dict[gran]  # [num_entities, time_span]
                    time_span = ent_time_emb.shape[1]
                    ent_time_feature_gran = torch.mm(ent_time_emb, time_span_feature) / max(time_span, 1.0)  # [num_entities, hidden_dim]
                    ent_time_features_list.append(ent_time_feature_gran)
            
            # Fuse multi-granular temporal features
            if len(ent_time_features_list) > 0:
                # Stack and concatenate features from all granularities
                stacked_features = torch.stack(ent_time_features_list, dim=1)  # [num_entities, num_granularities, hidden_dim]
                # Reshape to [num_entities, num_granularities * hidden_dim]
                concatenated_features = stacked_features.view(ent_name_feature.shape[0], -1)
                # Fuse using the fusion layer
                fused_time_feature = self.multi_granular_time2vec.fusion(concatenated_features)  # [num_entities, hidden_dim]
                # Final processing
                ent_time_feature = self.fc_time(self.fc_time_0(self.dropout(fused_time_feature)))  # [num_entities, time_size]
                features.append(ent_time_feature)
            else:
                # If no time features available, add zero feature
                zero_time_feature = torch.zeros(ent_name_feature.shape[0], self.time_size).to(self.device)
                features.append(zero_time_feature)
        
        if self.use_structure:
            ent_dw_feature = self.fc_dw(self.fc_dw_0(self.dropout(self.ent_dw_emb)))
            features.append(ent_dw_feature)

        output_feature = torch.cat(features, dim=1)
        output_feature = self.fc_final(output_feature)
        
        return output_feature

