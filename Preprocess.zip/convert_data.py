#!/usr/bin/env python3
"""Convert raw 1m and fb_dbp_2m data to DivEA format."""
import os, sys
from collections import defaultdict

RAW = "/root/autodl-tmp/HyDRA/Preprocess/data"
OUT = "/root/autodl-tmp/HyDRA/Preprocess/data"

def write_tab(fn, data):
    with open(fn, "w") as f:
        for items in data:
            f.write("\t".join(str(x) for x in items) + "\n")

def convert_1m(lang):
    """Convert 1m data for given language (de or fr)."""
    # KG1 = en, KG2 = de/fr
    raw_dir = os.path.join(RAW, "1m")
    out_dir = os.path.join(OUT, "1m", f"en_{lang}")
    os.makedirs(out_dir, exist_ok=True)
    
    print(f"\n=== Converting 1m en_{lang} ===")
    
    # --- Step 1: Build entity ID mappings from triples and ent_links ---
    en_entities = {}
    kg2_entities = {}
    en_relations = {}
    kg2_relations = {}
    
    def get_or_assign_ent(mapping, uri):
        if uri not in mapping:
            mapping[uri] = len(mapping)
        return mapping[uri]
    
    def get_or_assign_rel(mapping, uri):
        if uri not in mapping:
            mapping[uri] = len(mapping)
        return mapping[uri]
    
    # Parse triples_1 (en KG): head_uri \t rel_uri \t tail_uri
    triples_1_raw = []
    print(f"  Reading {lang}_triples_1...")
    with open(os.path.join(raw_dir, f"{lang}_triples_1")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            h, r, t = parts[0], parts[1], parts[2]
            hi = get_or_assign_ent(en_entities, h)
            ri = get_or_assign_rel(en_relations, r)
            ti = get_or_assign_ent(en_entities, t)
            triples_1_raw.append((hi, ti, ri))
    
    # Parse triples_2 (kg2 KG)
    triples_2_raw = []
    print(f"  Reading {lang}_triples_2...")
    with open(os.path.join(raw_dir, f"{lang}_triples_2")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            h, r, t = parts[0], parts[1], parts[2]
            hi = get_or_assign_ent(kg2_entities, h)
            ri = get_or_assign_rel(kg2_relations, r)
            ti = get_or_assign_ent(kg2_entities, t)
            triples_2_raw.append((hi, ti, ri))
    
    # Parse ent_links
    alignment = []
    print(f"  Reading {lang}_ent_links...")
    with open(os.path.join(raw_dir, f"{lang}_ent_links")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 2: continue
            en_uri, kg2_uri = parts[0], parts[1]
            # Both URIs should already be in entity mappings from triples
            en_id = en_entities.get(en_uri)
            kg2_id = kg2_entities.get(kg2_uri)
            if en_id is not None and kg2_id is not None:
                alignment.append((en_id, kg2_id))
    
    # Also handle strict versions (prefer strict for training if exists)
    # de_triples_strict_1, de_triples_strict_2 - these have fewer entities, use as supplement
    
    print(f"  en entities: {len(en_entities)}, {lang} entities: {len(kg2_entities)}")
    print(f"  en relations: {len(en_relations)}, {lang} relations: {len(kg2_relations)}")
    print(f"  alignment pairs: {len(alignment)}")
    
    # --- Step 2: Write DivEA format files ---
    # entity_id2uri: id \t uri
    write_tab(os.path.join(out_dir, "en_entity_id2uri.txt"),
              [(i, uri) for uri, i in sorted(en_entities.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, f"{lang}_entity_id2uri.txt"),
              [(i, uri) for uri, i in sorted(kg2_entities.items(), key=lambda x: x[1])])
    
    # relation_id2uri: id \t uri
    write_tab(os.path.join(out_dir, "en_relation_id2uri.txt"),
              [(i, uri) for uri, i in sorted(en_relations.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, f"{lang}_relation_id2uri.txt"),
              [(i, uri) for uri, i in sorted(kg2_relations.items(), key=lambda x: x[1])])
    
    # triple_rel: head_id \t tail_id \t rel_id
    write_tab(os.path.join(out_dir, "en_triple_rel.txt"), triples_1_raw)
    write_tab(os.path.join(out_dir, f"{lang}_triple_rel.txt"), triples_2_raw)
    
    # alignment
    write_tab(os.path.join(out_dir, "alignment_of_entity.txt"), alignment)
    
    print(f"  Done! Written to {out_dir}")

def convert_2m():
    """Convert fb_dbp_2m data."""
    raw_dir = os.path.join(RAW, "fb_dbp_2m")
    out_dir = os.path.join(OUT, "2m", "fb_dbp")
    os.makedirs(out_dir, exist_ok=True)
    
    print(f"\n=== Converting 2m fb_dbp ===")
    
    fb_entities = {}
    dbp_entities = {}
    fb_relations = {}
    dbp_relations = {}
    
    def get_ent(mapping, uri):
        if uri not in mapping:
            mapping[uri] = len(mapping)
        return mapping[uri]
    
    def get_rel(mapping, uri):
        if uri not in mapping:
            mapping[uri] = len(mapping)
        return mapping[uri]
    
    # Parse rel_triples_1 (Freebase KG)
    triples_1_raw = []
    print("  Reading rel_triples_1 (Freebase)...")
    with open(os.path.join(raw_dir, "rel_triples_1")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            h, r, t = parts[0].strip("<>"), parts[1].strip("<>"), parts[2].strip("<>")
            hi = get_ent(fb_entities, h)
            ri = get_rel(fb_relations, r)
            ti = get_ent(fb_entities, t)
            triples_1_raw.append((hi, ti, ri))
    
    # Parse rel_triples_2 (DBpedia KG)
    triples_2_raw = []
    print("  Reading rel_triples_2 (DBpedia)...")
    with open(os.path.join(raw_dir, "rel_triples_2")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            h, r, t = parts[0].strip("<>"), parts[1].strip("<>"), parts[2].strip("<>")
            hi = get_ent(dbp_entities, h)
            ri = get_rel(dbp_relations, r)
            ti = get_ent(dbp_entities, t)
            triples_2_raw.append((hi, ti, ri))
    
    # Parse ent_links
    alignment = []
    print("  Reading ent_links...")
    with open(os.path.join(raw_dir, "ent_links")) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 2: continue
            fb_uri, dbp_uri = parts[0].strip("<>"), parts[1].strip("<>")
            fb_id = fb_entities.get(fb_uri)
            dbp_id = dbp_entities.get(dbp_uri)
            if fb_id is not None and dbp_id is not None:
                alignment.append((fb_id, dbp_id))
    
    print(f"  fb entities: {len(fb_entities)}, dbp entities: {len(dbp_entities)}")
    print(f"  fb relations: {len(fb_relations)}, dbp relations: {len(dbp_relations)}")
    print(f"  alignment pairs: {len(alignment)}")
    
    # Write
    write_tab(os.path.join(out_dir, "fb_entity_id2uri.txt"),
              [(i, uri) for uri, i in sorted(fb_entities.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, "dbp_entity_id2uri.txt"),
              [(i, uri) for uri, i in sorted(dbp_entities.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, "fb_relation_id2uri.txt"),
              [(i, uri) for uri, i in sorted(fb_relations.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, "dbp_relation_id2uri.txt"),
              [(i, uri) for uri, i in sorted(dbp_relations.items(), key=lambda x: x[1])])
    write_tab(os.path.join(out_dir, "fb_triple_rel.txt"), triples_1_raw)
    write_tab(os.path.join(out_dir, "dbp_triple_rel.txt"), triples_2_raw)
    write_tab(os.path.join(out_dir, "alignment_of_entity.txt"), alignment)
    
    print(f"  Done! Written to {out_dir}")

if __name__ == "__main__":
    convert_1m("de")
    convert_1m("fr")
    convert_2m()
    print("\n=== All conversions complete! ===")
