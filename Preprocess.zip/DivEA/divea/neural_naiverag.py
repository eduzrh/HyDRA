# -*- coding: utf-8 -*-
"""
Naive RAG Entity Alignment — NeuralEAModule wrapper.

Method:
  1. For each source entity, retrieve top-K candidate target entities
     using embedding similarity (entity name embeddings)
  2. For each candidate pair, construct a prompt with entity names + neighbor context
  3. Ask LLM: "Are these entities the same? Answer yes/no."
  4. Collect confirmed pairs as predicted alignments

This is the simplest LLM-based EA baseline — single-pass retrieval + verification.
"""

import os
import json
import numpy as np
from typing import List, Tuple

from divea.util import Config
from divea.llm_ea.base_llm_ea import BaseLLMEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class NaiveRAGModule(BaseLLMEAModule):
    method_name = 'NaiveRAG'
    
    def __init__(self, conf: Config, llm_backend: LLMBackend = None, 
                 top_k: int = 10, batch_size: int = 16):
        super().__init__(conf, llm_backend)
        self.top_k = top_k
        self.batch_size = batch_size
    
    def _run_alignment(self, data_dir: str, output_dir: str) -> List[Tuple[int, int]]:
        os.makedirs(output_dir, exist_ok=True)
        
        # Get all entity IDs
        ent1_ids = sorted(self._entity_texts_1.keys())
        ent2_ids = sorted(self._entity_texts_2.keys())
        
        # ── Step 1: Retrieve top-K candidates via embedding similarity ──
        print(f'[NaiveRAG] Retrieving candidates for {len(ent1_ids)} source entities...')
        
        ent1_names = [self._entity_texts_1[i] for i in ent1_ids]
        ent2_names = [self._entity_texts_2[i] for i in ent2_ids]
        
        # Encode names to embeddings
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)
        
        # Cosine similarity
        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        sim_matrix = ent1_norm @ ent2_norm.T  # (N1, N2)
        
        # Get top-K for each source entity
        top_k_indices = np.argsort(-sim_matrix, axis=1)[:, :self.top_k]
        
        # ── Step 2: LLM verification ──
        print(f'[NaiveRAG] Verifying candidates with LLM...')
        
        predicted_pairs = []
        total_candidates = 0
        
        for i, src_idx in enumerate(ent1_ids):
            candidates = [(src_idx, ent2_ids[cand_j]) 
                         for cand_j in top_k_indices[i]]
            total_candidates += len(candidates)
            
            # Process in batches
            for batch_start in range(0, len(candidates), self.batch_size):
                batch = candidates[batch_start:batch_start + self.batch_size]
                prompts = []
                
                for e1, e2 in batch:
                    prompt = self._build_verification_prompt(e1, e2)
                    prompts.append(prompt)
                
                responses = self.llm.generate_batch(prompts, 
                    system_prompt='You are an entity alignment expert. Reply ONLY with yes or no.')
                
                for (e1, e2), resp in zip(batch, responses):
                    if self._parse_yes_no(resp):
                        predicted_pairs.append((e1, e2))
        
        print(f'[NaiveRAG] Verified {total_candidates} candidates, '
              f'found {len(predicted_pairs)} matches')
        
        # Save predictions
        with open(os.path.join(output_dir, 'naiverag_predictions.json'), 'w') as f:
            f.write(json.dumps({'pairs': predicted_pairs, 'n_candidates': total_candidates}))
        
        return predicted_pairs
    
    def _build_verification_prompt(self, e1: int, e2: int) -> str:
        """Build a prompt for the LLM to verify a candidate pair."""
        name1 = self._entity_texts_1.get(e1, f'E{e1}')
        name2 = self._entity_texts_2.get(e2, f'E{e2}')
        
        neighbors1 = self._get_neighbor_texts(e1, kg=1)
        neighbors2 = self._get_neighbor_texts(e2, kg=2)
        
        prompt = f"""Entity A: {name1}
Neighbors of A: {neighbors1}

Entity B: {name2}
Neighbors of B: {neighbors2}

Are Entity A and Entity B the same real-world entity? Answer ONLY 'yes' or 'no'."""
        return prompt
    
    def _parse_yes_no(self, response: str) -> bool:
        """Parse yes/no from LLM response."""
        response = response.strip().lower()
        return response.startswith('yes') or 'yes' in response[:10]
