# -*- coding: utf-8 -*-
"""
Unified Large-Scale Entry Script for HyDRA + ELsEA.

Supports 6 large-scale datasets:
  Temporal (TKGA-Wild):
    - TimeD1M/EN-FR   (1M entities, DBpedia EN-FR, temporal)
    - TimeD1M/EN-DE   (1M entities, DBpedia EN-DE, temporal)
    - Time-FB2M       (2M entities, Freebase-DBpedia, temporal)

  Static (Standard KGA):
    - DBP1M/EN-FR     (1M entities, DBpedia EN-FR, non-temporal)
    - DBP1M/EN-DE     (1M entities, DBpedia EN-DE, non-temporal)
    - FBDBP2M         (2M entities, Freebase-DBpedia, non-temporal)

Usage:
    # Temporal datasets
    python run_large_scale.py --dataset TimeD1M/EN-DE --ea_model hydra
    python run_large_scale.py --dataset Time-FB2M --ea_model hydra

    # Static datasets
    python run_large_scale.py --dataset DBP1M/EN-DE --ea_model hydra
    python run_large_scale.py --dataset FBDBP2M --ea_model hydra

    # Compare with baselines
    python run_large_scale.py --dataset DBP1M/EN-DE --ea_model rrea
    python run_large_scale.py --dataset DBP1M/EN-DE --ea_model dualamn
"""

import os
import sys
import torch
import shutil
import argparse
from os import makedirs
import multiprocessing

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from divea.dataload import UniformData
from divea.util import Config, seed_everything
from divea.framework import ParallelEAFramework
from divea.components_base import Client, Server
from divea.neural_gcnalign import GCNAlignModule
from divea.neural_dualamn import Dual_AMNModule
from divea.neural_lightea import LightEAModule
from divea.neural_rrea import RREAModule

# HyDRA + LLM-based EA models
from divea.neural_hydra import HyDRAModule
from divea.neural_naiverag import NaiveRAGModule
from divea.neural_selfconsistency import SelfConsistencyModule
from divea.neural_llm4ea import LLM4EAModule
from divea.neural_selfrag import SelfRAGModule
from divea.neural_chatea import ChatEAModule
from divea.llm_ea.llm_backend import MockBackend, OpenAIBackend

from divea.ctx_builder_onclient import CtxBuilderV1, CtxBuilderV2
from divea.components import DivG1Metis, DivG1Random, CounterpartDiscovery
from divea.graph_metrics import graph_metrics_main


# ============================================================================
# Dataset Configuration
# ============================================================================

DATASET_CONFIG = {
    # Temporal large-scale TKGA datasets (from LargeTKGA on HuggingFace)
    'TimeD1M/EN-FR': {
        'data_name': '1m_temporal',
        'kgids': ('en', 'fr'),
        'subtask_num': 100,
        'is_temporal': True,
        'description': 'Time-aware DBpedia 1M EN-FR (temporal KG alignment)',
        'source': 'LargeTKGA (HuggingFace: knowledgeAnonymous/LargeTKGA)',
    },
    'TimeD1M/EN-DE': {
        'data_name': '1m_temporal',
        'kgids': ('en', 'de'),
        'subtask_num': 100,
        'is_temporal': True,
        'description': 'Time-aware DBpedia 1M EN-DE (temporal KG alignment)',
        'source': 'LargeTKGA (HuggingFace: knowledgeAnonymous/LargeTKGA)',
    },
    'Time-FB2M': {
        'data_name': '2m_temporal',
        'kgids': ('fb', 'dbp'),
        'subtask_num': 200,
        'is_temporal': True,
        'description': 'Time-aware Freebase-DBpedia 2M (temporal KG alignment)',
        'source': 'LargeTKGA (HuggingFace: knowledgeAnonymous/LargeTKGA)',
    },

    # Static large-scale KGA datasets
    'DBP1M/EN-FR': {
        'data_name': '1m',
        'kgids': ('en', 'fr'),
        'subtask_num': 100,
        'is_temporal': False,
        'description': 'DBpedia 1M EN-FR (standard KG alignment)',
        'source': 'DBpedia 1M benchmark',
    },
    'DBP1M/EN-DE': {
        'data_name': '1m',
        'kgids': ('en', 'de'),
        'subtask_num': 100,
        'is_temporal': False,
        'description': 'DBpedia 1M EN-DE (standard KG alignment)',
        'source': 'DBpedia 1M benchmark',
    },
    'FBDBP2M': {
        'data_name': '2m',
        'kgids': ('fb', 'dbp'),
        'subtask_num': 200,
        'is_temporal': False,
        'description': 'Freebase-DBpedia 2M (standard KG alignment)',
        'source': 'FB-DBpedia 2M benchmark',
    },
}


def make_dirs(path):
    if not os.path.exists(path):
        makedirs(path)
    else:
        shutil.rmtree(path)
        makedirs(path)


def get_parser():
    parser = argparse.ArgumentParser(
        description='HyDRA + ELsEA: Large-Scale Entity Alignment',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Supported datasets:
  Temporal (TKGA-Wild):
    TimeD1M/EN-FR  TimeD1M/EN-DE  Time-FB2M
  Static (Standard KGA):
    DBP1M/EN-FR    DBP1M/EN-DE    FBDBP2M

Supported EA models:
  embedding-based: rrea, dualamn, gcn-align, lightea
  LLM-based: hydra, naiverag, selfconsistency, llm4ea, selfrag, chatea

Examples:
  python run_large_scale.py --dataset TimeD1M/EN-DE --ea_model hydra
  python run_large_scale.py --dataset DBP1M/EN-FR --ea_model hydra --max_iteration 3
  python run_large_scale.py --dataset FBDBP2M --ea_model rrea
  python run_large_scale.py --dataset Time-FB2M --ea_model hydra --gpu_ids 0,1,2,3
        """
    )

    # Dataset
    parser.add_argument('--dataset', type=str, required=True,
                        choices=list(DATASET_CONFIG.keys()),
                        help='Dataset name')
    parser.add_argument('--data_dir', type=str, default='../data/',
                        help='Input dataset directory')
    parser.add_argument('--output_dir', type=str, default='../results/DivEA/',
                        help='Output directory')

    # Subtask configuration
    parser.add_argument('--subtask_size', type=str, default='1.0',
                        help='Subtask size (int) or ratio (float 0-1)')
    parser.add_argument('--ctx_g1_percent', type=float, default=0.5,
                        help='Percentage of first context graph size')
    parser.add_argument('--ctx_g2_conn_percent', type=float, default=0.0,
                        help='Percentage of connecting entities in G2 context')

    # Module configuration
    parser.add_argument('--ctx_builder', type=str, default='v1',
                        choices=['v1', 'v2'],
                        help='v1: build ctx on client; v2: build ctx on server')
    parser.add_argument('--div_g1', type=str, default='metis',
                        choices=['metis', 'random'],
                        help='Method of partitioning KG1')
    parser.add_argument('--counterdisc_ablation', type=str, default='full',
                        choices=['full', 'locality'],
                        help='Ablation study of counterpart discovery')

    # Hyper-parameters
    parser.add_argument('--alpha', type=float, default=0.9)
    parser.add_argument('--beta', type=float, default=1.0)
    parser.add_argument('--gamma', type=float, default=2.0)
    parser.add_argument('--topK', type=int, default=10)
    parser.add_argument('--max_iteration', type=int, default=5)

    # EA model
    parser.add_argument('--ea_model', type=str, default='hydra',
                        choices=['rrea', 'dualamn', 'gcn-align', 'lightea',
                                 'hydra', 'naiverag', 'selfconsistency',
                                 'llm4ea', 'selfrag', 'chatea'],
                        help='EA model')
    parser.add_argument('--eval_way', type=str, default='sinkhorn',
                        choices=['csls', 'cosine', 'sinkhorn'])
    parser.add_argument('--layer_num', type=int, default=2)
    parser.add_argument('--max_train_epoch', type=int, default=50)

    # LLM backend (for LLM-based models)
    parser.add_argument('--llm_backend', type=str, default='mock',
                        choices=['mock', 'openai', 'local'])
    parser.add_argument('--llm_api_key', type=str, default='')
    parser.add_argument('--llm_base_url', type=str, default='')
    parser.add_argument('--llm_model', type=str, default='gpt-4o-mini')
    parser.add_argument('--llm_local_model', type=str,
                        default='Qwen/Qwen2.5-7B-Instruct')

    # HyDRA-specific
    parser.add_argument('--hydra_skip_s4', action='store_true',
                        help='Skip HyDRA Stage 1 (Encoding & Integration)')
    parser.add_argument('--hydra_epochs', type=int, default=500,
                        help='HyDRA Stage 1 training epochs')

    # Device & environment
    parser.add_argument('--gpu_ids', type=str, default='0,1,2,3')
    parser.add_argument('--py_exe_fn', type=str, default=None)
    parser.add_argument('--is_mulprocess', type=bool, default=True)
    parser.add_argument('--proc_n', type=int, default=20)
    parser.add_argument('--seed', type=int, default=1011)

    return parser


def main():
    args = get_parser().parse_args()

    # Get dataset config
    if args.dataset not in DATASET_CONFIG:
        print(f'Error: Unknown dataset: {args.dataset}')
        print(f'Available: {", ".join(DATASET_CONFIG.keys())}')
        sys.exit(1)

    cfg = DATASET_CONFIG[args.dataset]

    print("=" * 80)
    print(f"HyDRA + ELsEA: Large-Scale Entity Alignment")
    print("=" * 80)
    print(f"Dataset: {args.dataset}")
    print(f"  Description: {cfg['description']}")
    print(f"  Source: {cfg['source']}")
    print(f"  Temporal: {cfg['is_temporal']}")
    print(f"  KG IDs: {cfg['kgids']}")
    print(f"  Subtasks: {cfg['subtask_num']}")
    print(f"EA Model: {args.ea_model}")
    print(f"Eval Method: {args.eval_way}")
    print(f"Max Iterations: {args.max_iteration}")
    print("=" * 80)

    kgids = cfg['kgids']
    data_dir = os.path.join(args.data_dir, cfg['data_name'], "_".join(kgids))
    out_dir = os.path.join(
        args.output_dir, cfg['data_name'],
        "_".join(kgids), args.dataset,
        args.ea_model, args.eval_way
    )

    print(f"\nData directory: {data_dir}")
    print(f"Output directory: {out_dir}")

    if not os.path.exists(data_dir):
        print(f"\nError: Data directory not found: {data_dir}")
        print(f"\nIf using temporal datasets, please download from:")
        print(f"  https://huggingface.co/datasets/knowledgeAnonymous/LargeTKGA")
        print(f"  Password: largetkga")
        print(f"\nThen extract to: {os.path.join(args.data_dir, cfg['data_name'])}/")
        sys.exit(1)

    make_dirs(out_dir)
    seed_everything(args.seed)

    num_threads = multiprocessing.cpu_count()
    print(f"CPU threads: {num_threads}")
    args.proc_n = min(num_threads, args.proc_n)

    gpu_list = args.gpu_ids.split(",")
    args.gpu_ids = ",".join(gpu_list[:torch.cuda.device_count()])

    # Load data
    print("\nLoading KG data...")
    data = UniformData(data_dir, kgids)
    print(f"  KG1 entities: {len(data.kg1_entities)}, relations: {len(data.kg1_relations)}")
    print(f"  KG2 entities: {len(data.kg2_entities)}, relations: {len(data.kg2_relations)}")
    print(f"  KG1 triples: {len(data.kg1_triples)}, KG2 triples: {len(data.kg2_triples)}")

    # Compute graph metrics (node/edge weights)
    print("\nComputing graph metrics...")
    graph_metrics_main(data)
    data.load_weights()

    subtask_size = eval(args.subtask_size)
    if isinstance(subtask_size, float):
        total_kg_size = len(data.kg1_entities) + len(data.kg2_entities)
        subtask_size = int(subtask_size * total_kg_size / cfg['subtask_num'])

    ctx_g1_size = int(subtask_size * args.ctx_g1_percent)
    ctx_g2_size = subtask_size - ctx_g1_size

    # Context builder
    if args.ctx_builder == "v1":
        ctx_builder = CtxBuilderV1(
            data, data_dir, kgids, out_dir, cfg['subtask_num'],
            args.layer_num, gamma=args.gamma,
            ctx_g1_size=ctx_g1_size, ctx_g2_size=ctx_g2_size,
            ctx_g2_conn_percent=args.ctx_g2_conn_percent,
            torch_devices=[f"cuda:{didx}" for didx in range(len(gpu_list))],
            is_mulprocess=args.is_mulprocess, proc_n=args.proc_n
        )
    else:
        ctx_builder = CtxBuilderV2(
            data, data_dir, kgids, out_dir, cfg['subtask_num'],
            args.layer_num, gamma=args.gamma,
            ctx_g1_size=ctx_g1_size, ctx_g2_size=ctx_g2_size,
            ctx_g2_conn_percent=args.ctx_g2_conn_percent,
            torch_devices=[f"cuda:{didx}" for didx in range(len(gpu_list))],
            is_mulprocess=args.is_mulprocess, proc_n=args.proc_n
        )

    # G1 partitioner
    if args.div_g1 == "metis":
        g1_partitioner = DivG1Metis(data, data_dir, kgids, cfg['subtask_num'], balance=False)
    elif args.div_g1 == "random":
        g1_partitioner = DivG1Random(data, data_dir, kgids, cfg['subtask_num'])
    else:
        raise Exception("unknown g1 partition method")

    # Counterpart discovery
    count_discover = CounterpartDiscovery(
        data, data_dir, kgids, cfg['subtask_num'],
        ctx_g2_size=ctx_g2_size,
        max_hop_k=2 * args.layer_num, out_dir=out_dir,
        alpha=args.alpha, beta=args.beta, topK=args.topK,
        ablation=args.counterdisc_ablation
    )

    # LLM backend setup
    llm_backend = None
    llm_ea_models = {"naiverag", "selfconsistency", "llm4ea", "selfrag", "chatea"}
    if args.ea_model in llm_ea_models or args.ea_model == "hydra":
        if args.llm_backend == "openai":
            llm_backend = OpenAIBackend(
                api_key=args.llm_api_key or None,
                base_url=args.llm_base_url or None,
                model=args.llm_model,
            )
            print(f"LLM backend: OpenAI ({args.llm_model})")
        elif args.llm_backend == "local":
            try:
                from divea.llm_ea.llm_backend import LocalModelBackend
                llm_backend = LocalModelBackend(model_name=args.llm_local_model)
                print(f"LLM backend: Local ({args.llm_local_model})")
            except ImportError:
                print("Warning: LocalModelBackend not available, using mock backend")
                llm_backend = MockBackend()
        else:
            llm_backend = MockBackend()
            print("LLM backend: Mock (testing only)")

    # Server and clients
    server = Server(data_dir, kgids, out_dir, cfg['subtask_num'],
                    g1_partitioner, count_discover, ctx_builder)
    clients = []

    print(f"\nCreating {cfg['subtask_num']} clients with {args.ea_model} model...")

    for part_idx in range(1, cfg['subtask_num'] + 1):
        conf = Config()
        part_data_dir = os.path.join(data_dir, f"partition_{part_idx}")
        part_out_dir = os.path.join(out_dir, f"partition_{part_idx}")
        conf.data_dir = part_data_dir
        conf.output_dir = part_out_dir
        conf.kgids = kgids
        conf.max_train_epoch = args.max_train_epoch
        conf.gcn_layer_num = args.layer_num
        conf.py_exe_fn = args.py_exe_fn or sys.executable

        gpu_id = gpu_list[part_idx % len(gpu_list)]
        conf.gpu_ids = gpu_id
        conf.tf_gpu_id = int(gpu_id)
        conf.torch_device = torch.device(f"cuda:{gpu_id}")

        # HyDRA-specific config
        conf.hydra_skip_s4 = args.hydra_skip_s4
        conf.hydra_epochs = args.hydra_epochs
        conf.hydra_global_data_dir = data_dir
        conf.hydra_py_exe = args.py_exe_fn or sys.executable

        # LLM config
        conf.llm_global_data_dir = data_dir

        # EA model selection
        if args.ea_model == "rrea":
            ea_module = RREAModule(conf)
        elif args.ea_model == "dualamn":
            conf.py_exe_fn = "python"
            ea_module = Dual_AMNModule(conf)
        elif args.ea_model == "lightea":
            conf.py_exe_fn = "python"
            ea_module = LightEAModule(conf)
        elif args.ea_model == "gcn-align":
            conf.py_exe_fn = "python"
            ea_module = GCNAlignModule(conf)
        elif args.ea_model == "hydra":
            print(f"  [Partition {part_idx}] Using HyDRA (temporal={cfg['is_temporal']})")
            ea_module = HyDRAModule(conf)
        elif args.ea_model == "naiverag":
            print(f"  [Partition {part_idx}] Using NaiveRAG")
            ea_module = NaiveRAGModule(conf, llm_backend=llm_backend)
        elif args.ea_model == "selfconsistency":
            print(f"  [Partition {part_idx}] Using SelfConsistency")
            ea_module = SelfConsistencyModule(conf, llm_backend=llm_backend)
        elif args.ea_model == "llm4ea":
            print(f"  [Partition {part_idx}] Using LLM4EA")
            ea_module = LLM4EAModule(conf, llm_backend=llm_backend)
        elif args.ea_model == "selfrag":
            print(f"  [Partition {part_idx}] Using SelfRAG")
            ea_module = SelfRAGModule(conf, llm_backend=llm_backend)
        elif args.ea_model == "chatea":
            print(f"  [Partition {part_idx}] Using ChatEA")
            ea_module = ChatEAModule(conf, llm_backend=llm_backend)
        else:
            conf.py_exe_fn = "python"
            ea_module = GCNAlignModule(conf)

        client = Client(part_data_dir, kgids, part_out_dir, ea_module,
                      is_temporal=cfg['is_temporal'])
        clients.append(client)

    # Run pipeline
    framework = ParallelEAFramework(
        server, clients,
        eval_way=args.eval_way,
        max_iteration=args.max_iteration
    )
    framework.run()

    print("\n" + "=" * 80)
    print(f"Large-scale pipeline completed!")
    print(f"Results saved to: {out_dir}")
    print("=" * 80)


if __name__ == "__main__":
    main()
