# -*- coding: utf-8 -*-
"""
Offset KG2 entity IDs to avoid collision with KG1 in S4/Simple-HHEA pipeline.

KG1: 0..N1-1 (unchanged)
KG2: N1..N1+N2-1 (shifted by N1)
Triples_2 and alignment pairs updated accordingly.
"""
import os, shutil

def read_tab_lines(fn):
    if not os.path.exists(fn): return []
    with open(fn, 'r', encoding='utf-8') as f:
        cont = f.read().strip()
        if not cont: return []
        return [tuple(line.split('\t')) for line in cont.split('\n')]

def write_tab_lines(tuples, fn):
    with open(fn, 'w', encoding='utf-8') as f:
        for t in tuples:
            f.write('\t'.join(str(e) for e in t) + '\n')

def offset_kg2(data_dir):
    # Read entity counts
    ent1 = read_tab_lines(os.path.join(data_dir, 'ent_ids_1'))
    ent2 = read_tab_lines(os.path.join(data_dir, 'ent_ids_2'))
    N1 = len(ent1)

    # Check if already offset (KG2 IDs >= N1)
    already = any(int(e[0]) >= N1 for e in ent2[:5] if len(e) >= 1)
    if already:
        print(f'  Already offset (N1={N1}), skipping')
        return N1

    # Backup
    backup = os.path.join(data_dir, 'elsEA_backup')
    os.makedirs(backup, exist_ok=True)
    for fn in ['triples_2', 'ent_ids_2', 'sup_pairs', 'ref_ent_ids', 'ref_pairs']:
        src = os.path.join(data_dir, fn)
        dst = os.path.join(backup, fn + '.before_offset')
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy2(src, dst)

    # Offset ent_ids_2
    new_ent2 = [(int(e[0]) + N1, e[1]) for e in ent2]
    write_tab_lines(new_ent2, os.path.join(data_dir, 'ent_ids_2'))
    print(f'  ent_ids_2: {len(ent2)} entities offset by {N1}')

    # Offset triples_2 (h, r, t, t0, t1)
    triples2 = read_tab_lines(os.path.join(data_dir, 'triples_2'))
    new_triples2 = []
    for t in triples2:
        h = int(t[0]) + N1
        r = int(t[1]) if len(t) > 1 else 0
        tl = int(t[2]) + N1
        t0, t1 = (int(t[3]), int(t[4])) if len(t) >= 5 else (0, 0)
        new_triples2.append((h, r, tl, t0, t1))
    write_tab_lines(new_triples2, os.path.join(data_dir, 'triples_2'))
    print(f'  triples_2: {len(triples2)} triples re-indexed')

    # Offset sup_pairs (e1, e2) -> e1 stays, e2 += N1
    sup = read_tab_lines(os.path.join(data_dir, 'sup_pairs'))
    if sup:
        new_sup = [(int(s[0]), int(s[1]) + N1) for s in sup]
        write_tab_lines(new_sup, os.path.join(data_dir, 'sup_pairs'))
        print(f'  sup_pairs: {len(sup)} pairs updated')

    # Offset ref_ent_ids
    ref = read_tab_lines(os.path.join(data_dir, 'ref_ent_ids'))
    if ref:
        new_ref = [(int(r[0]), int(r[1]) + N1) for r in ref]
        write_tab_lines(new_ref, os.path.join(data_dir, 'ref_ent_ids'))
        print(f'  ref_ent_ids: {len(ref)} pairs updated')

    # Offset ref_pairs (same format as ref_ent_ids)
    rp = read_tab_lines(os.path.join(data_dir, 'ref_pairs'))
    if rp:
        new_rp = [(int(r[0]), int(r[1]) + N1) for r in rp]
        write_tab_lines(new_rp, os.path.join(data_dir, 'ref_pairs'))
        print(f'  ref_pairs: {len(rp)} pairs updated')

    return N1

if __name__ == '__main__':
    import sys
    d = sys.argv[1] if len(sys.argv) > 1 else '/root/autodl-tmp/HyDRA/Preprocess/data/1m/en_de/partition_2'
    n1 = offset_kg2(d)
    print(f'Done. N1={n1}')
