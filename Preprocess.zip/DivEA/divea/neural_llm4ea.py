# -*- coding: utf-8 -*-
"""LLM4EA - Direct LLM-based Entity Alignment with structured prompts and few-shot."""

import os, json, re, numpy as np
from typing import List, Tuple

from divea.util import Config
from divea.llm_ea.base_llm_ea import BaseLLMEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class LLM4EAModule(BaseLLMEAModule):
    method_name = "LLM4EA"

    def __init__(self, conf, llm_backend=None, n_few_shot=3, top_k=20):
        super().__init__(conf, llm_backend)
        self.n_few_shot = n_few_shot
        self.top_k = top_k

    def _run_alignment(self, data_dir, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        ent1_ids = sorted(self._entity_texts_1.keys())
        ent2_ids = sorted(self._entity_texts_2.keys())
        train_pairs = self._load_train_pairs()
        print("[LLM4EA] {} training pairs".format(len(train_pairs)))

        ent1_names = [self._entity_texts_1[i] for i in ent1_ids]
        ent2_names = [self._entity_texts_2[i] for i in ent2_ids]
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)

        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        sim_matrix = ent1_norm @ ent2_norm.T
        top_k_indices = np.argsort(-sim_matrix, axis=1)[:, :self.top_k]

        few_shot = self._build_few_shot(train_pairs[:self.n_few_shot])
        predicted_pairs = []
        batch_size = 50

        for batch_start in range(0, len(ent1_ids), batch_size):
            batch_end = min(batch_start + batch_size, len(ent1_ids))
            batch_entities = ent1_ids[batch_start:batch_end]
            prompt = self._build_batch_prompt(batch_entities, ent2_ids,
                                              top_k_indices[batch_start:batch_end], few_shot)
            response = self.llm.generate(prompt,
                system_prompt="Entity alignment system. Output: source_id: target_id per line. Use -1 for no match.",
                temperature=0.1, max_tokens=2048)
            pairs = self._parse_response(response, batch_entities)
            predicted_pairs.extend(pairs)

        print("[LLM4EA] Predicted {} pairs".format(len(predicted_pairs)))
        with open(os.path.join(output_dir, "llm4ea_predictions.json"), "w") as f:
            json.dump({"pairs": predicted_pairs}, f)
        return predicted_pairs

    def _build_few_shot(self, train_pairs):
        if not train_pairs:
            return "(No training examples)"
        examples = []
        for e1, e2 in train_pairs[:self.n_few_shot]:
            n1 = self._entity_texts_1.get(e1, "E{}".format(e1))
            n2 = self._entity_texts_2.get(e2, "E{}".format(e2))
            examples.append("{}: {} -> {}: {}".format(e1, n1, e2, n2))
        return "\n".join(examples)

    def _build_batch_prompt(self, entities, ent2_ids, batch_top_k, few_shot):
        lines = []
        for i, e1 in enumerate(entities):
            name1 = self._entity_texts_1.get(e1, "E{}".format(e1))
            neighbors1 = self._get_neighbor_texts(e1, kg=1, max_neighbors=5)
            candidates = [ent2_ids[j] for j in batch_top_k[i]]
            c_strs = ["  [{}] {}".format(e2, self._entity_texts_2.get(e2, "E{}".format(e2))) for e2 in candidates]
            lines.append("Source [{}]: {}\n  Neighbors: {}\n  Candidates:\n{}".format(
                e1, name1, neighbors1, "\n".join(c_strs)))
        header = "Training examples:\n{}\n\n".format(few_shot)
        header += "For each source entity, select the best matching candidate.\n"
        header += "Consider name similarity, structural context, and cross-lingual patterns.\n"
        header += "Output format: source_id: target_id (one per line, use -1 for no match).\n\n"
        header += "\n\n".join(lines)
        header += "\n\nPredictions:"
        return header

    def _parse_response(self, response, batch_entities):
        pairs = []
        for line in response.strip().split("\n"):
            match = re.match(r"(\d+)\s*[:,\->]+\s*(-?\d+)", line.strip())
            if match:
                src_id = int(match.group(1))
                tgt_id = int(match.group(2))
                if src_id in batch_entities and tgt_id >= 0:
                    pairs.append((src_id, tgt_id))
        return pairs