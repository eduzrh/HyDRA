# -*- coding: utf-8 -*-
"""
LLM Backend abstraction for LLM-based EA methods.

Supports:
  - OpenAI-compatible API (GPT, Claude via proxy, local vLLM, etc.)
  - Local HuggingFace models (transformers)

Usage:
    backend = OpenAIBackend(api_key='...', model='gpt-4o-mini')
    backend = LocalModelBackend(model_name='Qwen/Qwen2.5-7B-Instruct')
    response = backend.generate('Hello, who are you?')
"""

import os
import json
import time
from abc import ABC, abstractmethod
from typing import List, Optional, Dict


class LLMBackend(ABC):
    """Abstract LLM backend."""
    
    @abstractmethod
    def generate(self, prompt: str, system_prompt: str = None, 
                 temperature: float = 0.1, max_tokens: int = 512) -> str:
        """Generate a response from the LLM."""
        pass
    
    @abstractmethod
    def generate_batch(self, prompts: List[str], system_prompt: str = None,
                       temperature: float = 0.1, max_tokens: int = 512) -> List[str]:
        """Generate responses for multiple prompts."""
        pass
    
    def embed(self, texts: List[str]) -> 'np.ndarray':
        """Get embeddings for texts. Default: simple TF-IDF."""
        import numpy as np
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            vectorizer = TfidfVectorizer(max_features=256)
            return vectorizer.fit_transform(texts).toarray().astype(np.float32)
        except ImportError:
            # Ultr-simple fallback
            return np.random.randn(len(texts), 256).astype(np.float32)


class OpenAIBackend(LLMBackend):
    """OpenAI-compatible API backend.
    
    Works with:
      - OpenAI API (api_key, model='gpt-4o-mini')
      - Anthropic API via compatible proxy
      - Local vLLM/TGI server (base_url='http://localhost:8000/v1')
      - Any OpenAI-compatible endpoint
    """
    
    def __init__(self, api_key: str = None, base_url: str = None,
                 model: str = 'gpt-4o-mini', timeout: int = 60,
                 max_retries: int = 3):
        self.api_key = api_key or os.environ.get('OPENAI_API_KEY', '')
        self.base_url = base_url or os.environ.get('OPENAI_BASE_URL', None)
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        
        self._client = None
    
    @property
    def client(self):
        if self._client is None:
            try:
                from openai import OpenAI
                kwargs = {'api_key': self.api_key, 'timeout': self.timeout}
                if self.base_url:
                    kwargs['base_url'] = self.base_url
                self._client = OpenAI(**kwargs)
            except ImportError:
                raise ImportError('openai package required. Install: pip install openai')
        return self._client
    
    def generate(self, prompt: str, system_prompt: str = None,
                 temperature: float = 0.1, max_tokens: int = 512) -> str:
        messages = []
        if system_prompt:
            messages.append({'role': 'system', 'content': system_prompt})
        messages.append({'role': 'user', 'content': prompt})
        
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                return response.choices[0].message.content.strip()
            except Exception as e:
                if attempt == self.max_retries - 1:
                    print(f'[LLM] API error after {self.max_retries} retries: {e}')
                    return ''
                time.sleep(2 ** attempt)
        return ''
    
    def generate_batch(self, prompts: List[str], system_prompt: str = None,
                       temperature: float = 0.1, max_tokens: int = 512) -> List[str]:
        return [self.generate(p, system_prompt, temperature, max_tokens) for p in prompts]


class LocalModelBackend(LLMBackend):
    """Local HuggingFace model backend (for offline use)."""
    
    def __init__(self, model_name: str = 'Qwen/Qwen2.5-7B-Instruct',
                 device: str = 'cuda', load_in_4bit: bool = True):
        self.model_name = model_name
        self.device = device
        self.load_in_4bit = load_in_4bit
        self._model = None
        self._tokenizer = None
    
    def _load_model(self):
        if self._model is None:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            print(f'[LLM] Loading local model: {self.model_name}')
            
            kwargs = {'device_map': 'auto', 'trust_remote_code': True}
            if self.load_in_4bit:
                kwargs['load_in_4bit'] = True
            
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name, trust_remote_code=True)
            self._model = AutoModelForCausalLM.from_pretrained(self.model_name, **kwargs)
    
    def generate(self, prompt: str, system_prompt: str = None,
                 temperature: float = 0.1, max_tokens: int = 512) -> str:
        self._load_model()
        
        if system_prompt:
            full_prompt = f'{system_prompt}\n\n{prompt}'
        else:
            full_prompt = prompt
        
        inputs = self._tokenizer(full_prompt, return_tensors='pt').to(self._model.device)
        outputs = self._model.generate(
            **inputs,
            max_new_tokens=max_tokens,
            temperature=temperature,
            do_sample=temperature > 0,
            pad_token_id=self._tokenizer.eos_token_id,
        )
        response = self._tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
        return response.strip()
    
    def generate_batch(self, prompts: List[str], system_prompt: str = None,
                       temperature: float = 0.1, max_tokens: int = 512) -> List[str]:
        return [self.generate(p, system_prompt, temperature, max_tokens) for p in prompts]


class MockBackend(LLMBackend):
    """Mock backend for testing without a real LLM.
    
    Returns deterministic responses based on entity name overlap.
    Useful for pipeline testing before connecting a real LLM.
    """
    
    def generate(self, prompt: str, system_prompt: str = None,
                 temperature: float = 0.1, max_tokens: int = 512) -> str:
        # Simple heuristic: extract entity names from prompt and return best guess
        # This is NOT accurate — it's just for testing the pipeline
        return 'yes'  # Default: always says match
    
    def generate_batch(self, prompts: List[str], system_prompt: str = None,
                       temperature: float = 0.1, max_tokens: int = 512) -> List[str]:
        return ['yes'] * len(prompts)
    
    def embed(self, texts: List[str]) -> 'np.ndarray':
        import numpy as np
        # Simple character n-gram based embedding
        def simple_hash(s, dim=256):
            import hashlib
            h = hashlib.md5(s.encode()).digest()
            return np.array([float(b) / 255.0 for b in h[:dim]] + [0.0] * (dim - len(h[:dim])))
        
        return np.array([simple_hash(t) for t in texts], dtype=np.float32)
