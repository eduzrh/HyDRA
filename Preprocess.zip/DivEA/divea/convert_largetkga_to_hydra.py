# -*- coding: utf-8 -*-
"""
Temporal Data Format Converter for HyDRA + ELsEA.

Converts temporal large-scale KG data (from LargeTKGA on HuggingFace)
into the format required by HyDRA + ELsEA pipeline.

Usage:
    python convert_largetkga_to_hydra.py --data_dir /path/to/raw/temporal/data --kgids en,de
"""

import os
import re
import json
import argparse
import numpy as np
from collections import defaultdict


# ============================================================================
# Data Format Specification (HyDRA + ELsEA Standard)
# ============================================================================
#
# Raw temporal data should have:
#   - KG1 triples:  head_id, relation_id, tail_id, time_start, time_end
#   - KG2 triples:  head_id, relation_id, tail_id, time_start, time_end
#   - KG1 entities: id, URI or name
#   - KG2 entities: id, URI or name
#   - Relations: id, name
#   - Alignment: kg1_id, kg2_id
#
# Output files for ELsEA/HyDRA pipeline:
#   {kgid1}_triple_rel.txt        - 3-col: head_id, tail_id, rel_id
#   {kgid2}_triple_rel.txt        - 3-col: head_id, tail_id, rel_id
#   {kgid1}_entity_id2uri.txt     - 2-col: id, URI
#   {kgid2}_entity_id2uri.txt     - 2-col: id, URI
#   {kgid1}_relation_id2uri.txt   - 2-col: id, name
#   {kgid2}_relation_id2uri.txt   - 2-col: id, name
#   alignment_of_entity.txt         - 2-col: kg1_id, kg2_id
#   train_alignment.txt            - 2-col: kg1_id, kg2_id (20%)
#   test_alignment.txt             - 2-col: kg1_id, kg2_id (80%)
#   time_id.txt                    - 2-col: time_id, time_string (YYYY-MM-DD or YYYY-MM)
#   KGs_edge_info.json             - edge statistics
#   KGs_node_info.json             - node statistics
#   en_entity_txt.json            - entity name text for HyDRA


def read_lines(fn, encoding='utf-8'):
    """Read all non-empty lines from a file."""
    if not os.path.exists(fn):
        return []
    with open(fn, 'r', encoding=encoding) as f:
        lines = [l.rstrip('\n\r') for l in f]
    return [l for l in lines if l.strip()]


def write_lines(lines, fn, encoding='utf-8'):
    """Write lines to a file."""
    os.makedirs(os.path.dirname(fn) or '.', exist_ok=True)
    with open(fn, 'w', encoding=encoding) as f:
        f.write('\n'.join(lines) + '\n')


def extract_entity_name_from_uri(uri):
    """Extract readable entity name from DBpedia/Freebase URI."""
    # DBpedia: http://dbpedia.org/resource/Name
    m = re.search(r'/resource/(.+)$', uri)
    if m:
        name = m.group(1).replace('_', ' ')
        name = re.sub(r'%([0-9A-Fa-f]{2})', lambda x: chr(int(x.group(1), 16)), name)
        return name
    # Freebase: http://rdf.freebase.com/ns/m.0xxxxx
    m = re.search(r'/ns/(m\.[a-z0-9]+)$', uri)
    if m:
        return m.group(1)
    return uri


def parse_time_string(time_str):
    """
    Parse time string to (start_time_id, end_time_id).
    Returns (start_id, end_id) where IDs index into time_id.txt.

    Time granularity mapping:
      YYYY-MM-DD -> daily  (e.g., 2014-08-17 -> 5110)
      YYYY-MM    -> monthly (e.g., 2014-08 -> 24432)
      YYYY       -> yearly  (e.g., 2014 -> 2014)
    """
    time_str = time_str.strip()
    if not time_str or time_str in ('0', 'N/A', 'null', ''):
        return 0, 0

    # Normalize separators
    time_str = time_str.replace('/', '-').replace(' ', '-')

    # Try different formats
    for pattern, gran in [
        (r'^(-?\d{1,5})-(\d{1,2})-(\d{1,2})$', 'day'),     # YYYY-MM-DD or -YYYY-MM-DD
        (r'^(-?\d{1,5})-(\d{1,2})$', 'month'),               # YYYY-MM or -YYYY-MM
        (r'^(-?\d{1,5})$', 'year'),                          # YYYY or -YYYY
    ]:
        m = re.match(pattern, time_str)
        if m:
            return _time_to_id(gran, m.groups())
    return 0, 0


def _time_to_id(granularity, parts):
    """
    Convert time components to a single integer time ID.
    Uses the same encoding as icews_wiki / WildBETA.
    """
    if granularity == 'day':
        year = int(parts[0])
        month = int(parts[1])
        day = int(parts[2])
        # Encode as: (year + 5000) * 10000 + month * 100 + day
        # Supports years from -5000 to +4999
        encoded = (year + 5000) * 10000 + month * 100 + day
        return encoded, encoded
    elif granularity == 'month':
        year = int(parts[0])
        month = int(parts[1])
        encoded = (year + 5000) * 100 + month
        return encoded, encoded
    else:  # year
        year = int(parts[0])
        return year + 5000, year + 5000


def build_time_id_file(time_set, granularity_hint='auto'):
    """
    Build time_id.txt from a set of time strings.
    Returns list of (time_id, time_string) tuples sorted by time_id.
    """
    time_entries = []
    for t in sorted(time_set):
        tid, _ = parse_time_string(t)
        time_entries.append((tid, t))
    # Deduplicate by time string
    seen = {}
    for tid, ts in time_entries:
        if ts not in seen:
            seen[ts] = tid
    result = sorted(seen.items(), key=lambda x: x[1])
    return [(str(tid), ts) for ts, tid in result]


def convert_raw_temporal_to_elsEA(data_dir, kgids, train_ratio=0.2,
                                   time_granularity='auto'):
    """
    Convert raw temporal KG data to ELsEA standard format.

    Args:
        data_dir: Output directory for ELsEA-format data
        kgids: tuple of (kgid1, kgid2), e.g. ('en', 'de')
        train_ratio: fraction of alignment for training (default 0.2)
        time_granularity: 'auto', 'day', 'month', or 'year'

    Expected input format in data_dir (before conversion):
        {kgid1}_triple_rel.txt     - 5-col: h, r, t, time_start, time_end
        {kgid2}_triple_rel.txt     - 5-col: h, r, t, time_start, time_end
        {kgid1}_entity_id2uri.txt   - 2-col: id, URI
        {kgid2}_entity_id2uri.txt  - 2-col: id, URI
        {kgid1}_relation_id2uri.txt - 2-col: id, name
        {kgid2}_relation_id2uri.txt - 2-col: id, name
        alignment_of_entity.txt     - 2-col: kg1_id, kg2_id
        time_id.txt                - optional: time_id, time_string

    Output:
        Same files in ELsEA format (3-col triples, split alignment).
    """
    kgid1, kgid2 = kgids

    # Load 5-column triples
    kg1_triple_file = os.path.join(data_dir, f'{kgid1}_triple_rel.txt')
    kg2_triple_file = os.path.join(data_dir, f'{kgid2}_triple_rel.txt')

    print(f'Loading triples from {kg1_triple_file}')
    kg1_raw = read_lines(kg1_triple_file)
    kg2_raw = read_lines(kg2_triple_file)
    print(f'  KG1 triples: {len(kg1_raw)}, KG2 triples: {len(kg2_raw)}')

    # Parse 5-col triples
    kg1_triples = []
    kg2_triples = []
    time_strings = set()

    for line in kg1_raw:
        parts = line.split('\t')
        if len(parts) >= 5:
            h, r, t = int(parts[0]), int(parts[1]), int(parts[2])
            t_start = parts[3].strip() if len(parts) > 3 else '0'
            t_end = parts[4].strip() if len(parts) > 4 else '0'
            kg1_triples.append((h, t, r, t_start, t_end))
            time_strings.add(t_start)
            time_strings.add(t_end)
        elif len(parts) >= 3:
            kg1_triples.append((int(parts[0]), int(parts[2]), int(parts[1]), '0', '0'))

    for line in kg2_raw:
        parts = line.split('\t')
        if len(parts) >= 5:
            h, r, t = int(parts[0]), int(parts[1]), int(parts[2])
            t_start = parts[3].strip() if len(parts) > 3 else '0'
            t_end = parts[4].strip() if len(parts) > 4 else '0'
            kg2_triples.append((h, t, r, t_start, t_end))
            time_strings.add(t_start)
            time_strings.add(t_end)
        elif len(parts) >= 3:
            kg2_triples.append((int(parts[0]), int(parts[2]), int(parts[1]), '0', '0'))

    print(f'  Parsed: KG1={len(kg1_triples)}, KG2={len(kg2_triples)}, unique_times={len(time_strings)}')

    # Build entity and relation sets
    kg1_entities = set()
    kg2_entities = set()
    kg1_relations = set()
    kg2_relations = set()

    for h, t, r, _, _ in kg1_triples:
        kg1_entities.add(h)
        kg1_entities.add(t)
        kg1_relations.add(r)
    for h, t, r, _, _ in kg2_triples:
        kg2_entities.add(h)
        kg2_entities.add(t)
        kg2_relations.add(r)

    # Re-index entities and relations to 0-based contiguous
    kg1_ent_sorted = sorted(kg1_entities)
    kg2_ent_sorted = sorted(kg2_entities)
    kg1_rel_sorted = sorted(kg1_relations)
    kg2_rel_sorted = sorted(kg2_relations)

    kg1_e_old2new = {e: i for i, e in enumerate(kg1_ent_sorted)}
    kg2_e_old2new = {e: i for i, e in enumerate(kg2_ent_sorted)}
    kg1_r_old2new = {r: i for i, r in enumerate(kg1_rel_sorted)}
    kg2_r_old2new = {r: i for i, r in enumerate(kg2_rel_sorted)}

    # Build entity URI/name maps
    ent1_uri_map = {}
    ent2_uri_map = {}
    rel1_uri_map = {}
    rel2_uri_map = {}

    uri_file1 = os.path.join(data_dir, f'{kgid1}_entity_id2uri.txt')
    uri_file2 = os.path.join(data_dir, f'{kgid2}_entity_id2uri.txt')
    rel_file1 = os.path.join(data_dir, f'{kgid1}_relation_id2uri.txt')
    rel_file2 = os.path.join(data_dir, f'{kgid2}_relation_id2uri.txt')

    for line in read_lines(uri_file1):
        parts = line.split('\t')
        if len(parts) >= 2:
            ent1_uri_map[int(parts[0])] = parts[1]
    for line in read_lines(uri_file2):
        parts = line.split('\t')
        if len(parts) >= 2:
            ent2_uri_map[int(parts[0])] = parts[1]
    for line in read_lines(rel_file1):
        parts = line.split('\t')
        if len(parts) >= 2:
            rel1_uri_map[int(parts[0])] = parts[1]
    for line in read_lines(rel_file2):
        parts = line.split('\t')
        if len(parts) >= 2:
            rel2_uri_map[int(parts[0])] = parts[1]

    # Write entity ID files (re-indexed to 0-based)
    write_lines([f'{i}\t{ent1_uri_map.get(old, f"{kgid1}_entity_{old}")}'
                 for old, i in kg1_e_old2new.items()],
                os.path.join(data_dir, f'{kgid1}_entity_id2uri.txt'))
    write_lines([f'{i}\t{ent2_uri_map.get(old, f"{kgid2}_entity_{old}")}'
                 for old, i in kg2_e_old2new.items()],
                os.path.join(data_dir, f'{kgid2}_entity_id2uri.txt'))

    # Write relation ID files (re-indexed)
    write_lines([f'{i}\t{rel1_uri_map.get(old, f"{kgid1}_relation_{old}")}'
                 for old, i in kg1_r_old2new.items()],
                os.path.join(data_dir, f'{kgid1}_relation_id2uri.txt'))
    write_lines([f'{i}\t{rel2_uri_map.get(old, f"{kgid2}_relation_{old}")}'
                 for old, i in kg2_r_old2new.items()],
                os.path.join(data_dir, f'{kgid2}_relation_id2uri.txt'))

    # Write 3-col triples (ELsEA format: head, tail, rel)
    write_lines([f"{kg1_e_old2new[h]}\t{kg1_e_old2new[t]}\t{kg1_r_old2new[r]}"
                 for h, t, r, _, _ in kg1_triples
                 if h in kg1_e_old2new and t in kg1_e_old2new and r in kg1_r_old2new],
                os.path.join(data_dir, f'{kgid1}_triple_rel.txt'))
    write_lines([f"{kg2_e_old2new[h]}\t{kg2_e_old2new[t]}\t{kg2_r_old2new[r]}"
                 for h, t, r, _, _ in kg2_triples
                 if h in kg2_e_old2new and t in kg2_e_old2new and r in kg2_r_old2new],
                os.path.join(data_dir, f'{kgid2}_triple_rel.txt'))

    # Write entity text for HyDRA
    en_txt = {str(kg1_e_old2new[old]): extract_entity_name_from_uri(uri)
              for old, uri in ent1_uri_map.items() if old in kg1_e_old2new}
    with open(os.path.join(data_dir, 'en_entity_txt.json'), 'w', encoding='utf-8') as f:
        json.dump(en_txt, f, ensure_ascii=False, indent=2)

    # Load and split alignment
    align_file = os.path.join(data_dir, 'alignment_of_entity.txt')
    all_align = []
    for line in read_lines(align_file):
        parts = line.split('\t')
        if len(parts) >= 2:
            all_align.append((int(parts[0]), int(parts[1])))

    # Filter to entities in our re-indexed sets
    all_align = [(e1, e2) for e1, e2 in all_align
                 if e1 in kg1_e_old2new and e2 in kg2_e_old2new]
    all_align = [(kg1_e_old2new[e1], kg2_e_old2new[e2]) for e1, e2 in all_align]

    np.random.seed(42)
    np.random.shuffle(all_align)
    n_train = int(len(all_align) * train_ratio)
    train_align = all_align[:n_train]
    test_align = all_align[n_train:]

    write_lines([f'{e1}\t{e2}' for e1, e2 in all_align],
                os.path.join(data_dir, 'alignment_of_entity.txt'))
    write_lines([f'{e1}\t{e2}' for e1, e2 in train_align],
                os.path.join(data_dir, 'train_alignment.txt'))
    write_lines([f'{e1}\t{e2}' for e1, e2 in test_align],
                os.path.join(data_dir, 'test_alignment.txt'))

    # Write time_id.txt
    time_entries = build_time_id_file(time_strings, time_granularity)
    write_lines([f'{tid}\t{ts}' for tid, ts in time_entries],
                os.path.join(data_dir, 'time_id.txt'))

    # Write KG statistics
    kg_stats = {
        f'{kgid1}_nodes': len(kg1_entities),
        f'{kgid2}_nodes': len(kg2_entities),
        f'{kgid1}_edges': len(kg1_triples),
        f'{kgid2}_edges': len(kg2_triples),
        f'{kgid1}_relations': len(kg1_relations),
        f'{kgid2}_relations': len(kg2_relations),
        'alignment_total': len(all_align),
        'alignment_train': len(train_align),
        'alignment_test': len(test_align),
        'time_granularity': time_granularity,
        'num_time_ids': len(time_entries),
    }

    with open(os.path.join(data_dir, 'KGs_stats.json'), 'w') as f:
        json.dump(kg_stats, f, indent=2)

    print(f'\nConversion complete!')
    print(f'  KG1: {len(kg1_entities)} entities, {len(kg1_triples)} triples, {len(kg1_relations)} relations')
    print(f'  KG2: {len(kg2_entities)} entities, {len(kg2_triples)} triples, {len(kg2_relations)} relations')
    print(f'  Alignment: {len(all_align)} total ({len(train_align)} train, {len(test_align)} test)')
    print(f'  Time IDs: {len(time_entries)}')

    return kg_stats


def convert_csv_to_temporal_triples(csv_dir, kgid, output_file, time_col_idx=3):
    """
    Convert CSV format temporal data to 5-col triple format.

    Args:
        csv_dir: Directory containing CSV files
        kgid: KG identifier (en, de, etc.)
        output_file: Output file path for 5-col triples
        time_col_idx: Column index for time (default 3 = start, 4 = end)
    """
    import csv as csv_lib

    triples = []
    time_set = set()

    csv_path = os.path.join(csv_dir, f'{kgid}_triples.csv')
    if not os.path.exists(csv_path):
        print(f'CSV file not found: {csv_path}')
        return

    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv_lib.DictReader(f)
        for row in reader:
            h = int(row['head_id'])
            r = int(row['relation_id'])
            t = int(row['tail_id'])
            t_start = row.get('time_start', row.get('time', '0')).strip()
            t_end = row.get('time_end', t_start).strip()
            triples.append((h, r, t, t_start, t_end))
            time_set.add(t_start)
            time_set.add(t_end)

    write_lines(['\t'.join(map(str, t)) for t in triples], output_file)
    print(f'Converted {len(triples)} triples for {kgid}, {len(time_set)} time values')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Convert temporal large-scale KG data to ELsEA/HyDRA format')
    parser.add_argument('--data_dir', type=str, required=True,
                        help='Directory containing raw temporal data')
    parser.add_argument('--kgids', type=str, default='en,de',
                        help='KG IDs, e.g., en,de (comma-separated)')
    parser.add_argument('--train_ratio', type=float, default=0.2,
                        help='Train/test split ratio (default 0.2)')
    parser.add_argument('--time_granularity', type=str, default='auto',
                        choices=['auto', 'day', 'month', 'year'],
                        help='Time granularity (default auto)')

    args = parser.parse_args()
    kgids = tuple(args.kgids.split(','))

    convert_raw_temporal_to_elsEA(
        args.data_dir, kgids,
        train_ratio=args.train_ratio,
        time_granularity=args.time_granularity,
    )
