# -*- coding: utf-8 -*-
"""
HyDRA NeuralEAModule — integrates HyDRA (LLM-based temporal EA) into ELsEA framework.

HyDRA pipeline (4 stages):
  Stage 1: Encoding & Integration (Simple-HHEA: ALBERT + message passing)
  Stage 2: Scale-Adaptive Entity Projection (relation alignment + hypergraph decomposition)
  Stage 3: Multi-Scale Hypergraph Retrieval (FAISS + hypergraph retrieval)
  Stage 4: Multi-Scale Fusion (scale-weave fusion, produce final alignment)

For non-temporal datasets (e.g. DBPedia 1M), time columns are filled with 0.

Usage in Large_DivEA_run_1m.py:
    from divea.neural_hydra import HyDRAModule
    ea_module = HyDRAModule(conf)
"""

import os
import sys
import json
import subprocess
import numpy as np

from RREA.CSLS_torch import Evaluator

from divea.util import Config
from divea.dataload import read_alignment
from divea.convert_to_hydra import convert_uniform_to_hydra
from divea.components_base import NeuralEAModule


class HyDRAModule(NeuralEAModule):
    """HyDRA wrapper implementing NeuralEAModule for ELsEA integration.
    
    Config fields used:
        conf.data_dir      — partition data directory
        conf.output_dir    — partition output directory
        conf.kgids         — [kg1_id, kg2_id]
        conf.torch_device  — torch device
        conf.gpu_ids       — GPU ID (str, e.g. '0')
        
    HyDRA-specific config (set in conf or via kwargs):
        conf.hydra_skip_s4           — skip Stage 1 (Encoding & Integration) if False
        conf.hydra_epochs            — Stage 1 training epochs (default 500)
        conf.hydra_project_root      — HyDRA project root path
        conf.hydra_global_data_dir   — global data dir for entity name mapping
        conf.hydra_py_exe            — Python executable path (default sys.executable)
    """
    
    def __init__(self, conf: Config):
        super(HyDRAModule, self).__init__(conf)
        
        # HyDRA-specific defaults
        self.hydra_skip_s4 = getattr(conf, 'hydra_skip_s4', False)
        self.hydra_epochs = getattr(conf, 'hydra_epochs', 500)
        self.hydra_global_data_dir = getattr(conf, 'hydra_global_data_dir', None)
        self.hydra_py_exe = getattr(conf, 'hydra_py_exe', sys.executable)
        
        # Find HyDRA project root
        if hasattr(conf, 'hydra_project_root') and conf.hydra_project_root:
            self.hydra_root = conf.hydra_project_root
        else:
            # Auto-detect: go up from divea/ to DivEA/ to Preprocess/ to HyDRA/
            cur = os.path.dirname(os.path.realpath(__file__))  # divea/
            cur = os.path.dirname(cur)                          # DivEA/
            cur = os.path.dirname(cur)                          # Preprocess/
            cur = os.path.dirname(cur)                          # HyDRA/
            self.hydra_root = cur                               # HyDRA/
        
        # Paths to HyDRA scripts
        self.hydra_main = os.path.join(self.hydra_root, 'HyDRA_main.py')
        self.s4_script = os.path.join(self.hydra_root, 'encoding_and_integration', 'run_s4_standalone.py')
    
    def refresh_weights(self):
        pass
    
    def prepare_data(self):
        """Convert partition data to HyDRA format (5-col triples + entity names).
        
        For temporal datasets, the global time_id.txt file is passed through
        so that time strings can be resolved to time IDs.
        """
        print(f'[HyDRA] prepare_data: converting {self.conf.data_dir}')
        
        # If global_data_dir not set, use parent of partition dir, then parent again for global
        global_dir = self.hydra_global_data_dir
        if global_dir is None:
            # data_dir = .../partition_25 → parent = .../en_de/
            part_parent = os.path.dirname(self.conf.data_dir)
            global_dir = part_parent
        
        # Detect temporal: check if time_id.txt exists in global directory
        time_id_file = os.path.join(global_dir, 'time_id.txt')
        is_temporal = os.path.exists(time_id_file)
        
        if is_temporal:
            print(f'[HyDRA] Temporal dataset detected, preserving time info')
        else:
            print(f'[HyDRA] Non-temporal dataset (time_id.txt not found)')
        
        stats = convert_uniform_to_hydra(
            self.conf.data_dir,
            self.conf.kgids,
            global_data_dir=global_dir,
            preserve_temporal=is_temporal,
            time_id_file=time_id_file if is_temporal else None
        )
        print(f'[HyDRA] Conversion stats: {json.dumps(stats)}')
    
    def train_model(self):
        """Run HyDRA pipeline on the partition data."""
        print(f'[HyDRA] train_model: processing {self.conf.data_dir}')
        
        data_dir = self.conf.data_dir
        output_dir = self.conf.output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # ── Stage 1: Encoding & Integration ──
        if not self.hydra_skip_s4:
            self._run_stage1_encoding(data_dir)
        
        # ── Stage 2-4: Retrieval + Fusion ──
        # Skip Stage 2-4 if S4 is skipped (no integration output to use)
        s4_output = os.path.join(data_dir, 'message_pool', 'integration_top_pair.txt')
        if self.hydra_skip_s4:
            # Check if integration output already exists (from prior S4 run)
            if os.path.exists(s4_output) and os.path.getsize(s4_output) > 0:
                print(f'[HyDRA] S4 skipped but integration output found, running Stages 2-4')
                self._run_stage2_4_retrieval_fusion(data_dir, output_dir)
            else:
                print(f'[HyDRA] S4 skipped and no integration output, bypassing Stage 2-4')
                self._extract_embeddings(data_dir, output_dir)
        else:
            self._run_stage2_4_retrieval_fusion(data_dir, output_dir)
        
        print(f'[HyDRA] train_model complete for {data_dir}')
    
    def _run_stage1_encoding(self, data_dir):
        """Run Stage 1: Encoding & Integration (Simple-HHEA)."""
        print(f'[HyDRA] Stage 1: Encoding & Integration')
        
        if not os.path.exists(self.s4_script):
            print(f'[HyDRA] WARNING: {self.s4_script} not found, skipping Stage 1')
            return
        
        # Check if already done
        s4_output = os.path.join(data_dir, 'message_pool', 'integration_top_pair.txt')
        if os.path.exists(s4_output) and os.path.getsize(s4_output) > 0:
            print(f'[HyDRA] Stage 1 output exists, skipping')
            return
        
        gpu_id = str(self.conf.gpu_ids) if hasattr(self.conf, 'gpu_ids') else '0'
        
        cmd = [
            self.hydra_py_exe,
            self.s4_script,
            '--data_dir', data_dir,
            '--cuda', gpu_id,
            '--epochs', str(self.hydra_epochs),
        ]
        
        env = os.environ.copy()
        env['CUDA_VISIBLE_DEVICES'] = gpu_id
        env['HF_ENDPOINT'] = 'https://hf-mirror.com'
        
        print(f'[HyDRA] Running: {" ".join(cmd)}')
        try:
            result = subprocess.run(cmd, env=env, cwd=self.hydra_root,
                                   capture_output=True, text=True, timeout=7200)
            if result.returncode != 0:
                print(f'[HyDRA] Stage 1 stderr: {result.stderr[-2000:]}')
                # Non-fatal: continue with Stage 2-4 even if Stage 1 fails
                print(f'[HyDRA] WARNING: Stage 1 returned non-zero, continuing anyway')
            else:
                print(f'[HyDRA] Stage 1 complete')
        except subprocess.TimeoutExpired:
            print(f'[HyDRA] WARNING: Stage 1 timed out (2h), continuing')
        except Exception as e:
            print(f'[HyDRA] WARNING: Stage 1 error: {e}, continuing')
    
    def _run_stage2_4_retrieval_fusion(self, data_dir, output_dir):
        """Run Stage 2-4: Retrieval + Fusion using HyDRA_main.py."""
        print(f'[HyDRA] Stage 2-4: Retrieval & Fusion')
        
        gpu_id = str(self.conf.gpu_ids) if hasattr(self.conf, 'gpu_ids') else '0'
        
        cmd = [
            self.hydra_py_exe,
            self.hydra_main,
            '--data_dir', data_dir,
            '--skip_s4',  # Stage 1 already done (or skipped)
            '--cuda', gpu_id,
        ]
        
        env = os.environ.copy()
        env['CUDA_VISIBLE_DEVICES'] = gpu_id
        
        print(f'[HyDRA] Running: {" ".join(cmd)}')
        try:
            result = subprocess.run(cmd, env=env, cwd=self.hydra_root,
                                   capture_output=True, text=True, timeout=14400)
            if result.returncode != 0:
                print(f'[HyDRA] Stage 2-4 stderr: {result.stderr[-3000:]}')
                print(f'[HyDRA] Stage 2-4 stdout: {result.stdout[-3000:]}')
            else:
                print(f'[HyDRA] Stage 2-4 complete')
        except subprocess.TimeoutExpired:
            print(f'[HyDRA] WARNING: Stage 2-4 timed out (4h)')
        except Exception as e:
            print(f'[HyDRA] ERROR: Stage 2-4: {e}')
        
        # ── Extract embeddings from HyDRA output ──
        # HyDRA produces entity embeddings; find and copy to emb.npz
        self._extract_embeddings(data_dir, output_dir)
    

    def _load_text_format_embeddings(self, data_dir):
        """Try loading embeddings from text-format files generated by process_name_embedding.py.
        
        Looks for:
        - ent_ids_1_emb / ent_ids_2_emb: id\tv1,v2,...,v768 (tab + comma-separated)
        - ent_1_emb_64.txt / ent_2_emb_64.txt: np.savetxt format (space-separated)
        """
        import numpy as np
        import pandas as pd
        
        text_paths = [
            (os.path.join(data_dir, 'ent_ids_1_emb'), os.path.join(data_dir, 'ent_ids_2_emb'), 'csv_comma'),
            (os.path.join(data_dir, 'ent_1_emb_64.txt'), os.path.join(data_dir, 'ent_2_emb_64.txt'), 'savetxt'),
        ]
        
        for ent1_path, ent2_path, fmt in text_paths:
            if not os.path.exists(ent1_path) or not os.path.exists(ent2_path):
                continue
            try:
                if fmt == 'csv_comma':
                    df1 = pd.read_csv(ent1_path, sep='\t', header=None)
                    ent1_embs = df1[1].str.split(',', expand=True).astype(np.float32).values
                    df2 = pd.read_csv(ent2_path, sep='\t', header=None)
                    ent2_embs = df2[1].str.split(',', expand=True).astype(np.float32).values
                    print(f'[HyDRA] Loaded text-format embeddings (csv_comma): ent1={ent1_embs.shape}, ent2={ent2_embs.shape}')
                    return ent1_embs, ent2_embs
                elif fmt == 'savetxt':
                    ent1_embs = np.loadtxt(ent1_path, dtype=np.float32)
                    ent2_embs = np.loadtxt(ent2_path, dtype=np.float32)
                    print(f'[HyDRA] Loaded text-format embeddings (savetxt): ent1={ent1_embs.shape}, ent2={ent2_embs.shape}')
                    return ent1_embs, ent2_embs
            except Exception as e:
                print(f'[HyDRA] Failed to load text-format {fmt} from {ent1_path}: {e}')
                continue
        return None, None
    def _extract_embeddings(self, data_dir, output_dir):
        """Extract entity embeddings from HyDRA output and save as emb.npz.
        
        HyDRA may have produced embeddings in various locations:
        - data_dir/message_pool/entity_embeddings.npy
        - data_dir/encoded_entities.npy
        If not found, use a fallback: load ALBERT and encode entity names.
        """
        import numpy as np
        
        emb1_paths = [
            os.path.join(data_dir, 'message_pool', 'ent1_embeddings.npy'),
            os.path.join(data_dir, 'ent_ids_1_emb'),
        ]
        emb2_paths = [
            os.path.join(data_dir, 'message_pool', 'ent2_embeddings.npy'),
            os.path.join(data_dir, 'ent_ids_2_emb'),
        ]
        
        ent1_embs = None
        for p in emb1_paths:
            if os.path.exists(p):
                try:
                    # .npy file
                    ent1_embs = np.load(p)
                    break
                except:
                    pass
        
        ent2_embs = None
        for p in emb2_paths:
            if os.path.exists(p):
                try:
                    ent2_embs = np.load(p)
                    break
                except:
                    pass
        
        if ent1_embs is None or ent2_embs is None:
            # Try loading from text-format files (ent_ids_1_emb, ent_1_emb_64.txt, etc.)
            print('[HyDRA] .npy load failed, trying text-format embeddings...')
            ent1_embs, ent2_embs = self._load_text_format_embeddings(data_dir)
        
        if ent1_embs is None or ent2_embs is None:
            # Try loading via the S4 format (memory-mapped files)
            ent1_embs, ent2_embs = self._load_s4_embeddings(data_dir)
        
        if ent1_embs is None or ent2_embs is None:
            # Fallback: use ALBERT to encode entity names
            print('[HyDRA] No embeddings found, using ALBERT fallback encoding')
            ent1_embs, ent2_embs = self._fallback_encode(data_dir)
        
        if ent1_embs is not None and ent2_embs is not None:
            n1, d = ent1_embs.shape
            n2 = ent2_embs.shape[0]
            all_embs = np.concatenate([ent1_embs, ent2_embs], axis=0)
            ent1_ids = np.arange(n1)
            ent2_ids = np.arange(n1, n1 + n2)
            
            np.savez(
                os.path.join(output_dir, 'emb.npz'),
                embs=all_embs,
                ent1_ids=ent1_ids,
                ent2_ids=ent2_ids,
            )
            print(f'[HyDRA] Saved embeddings: {n1}+{n2} entities, dim={d}')
        else:
            print('[HyDRA] WARNING: Could not extract embeddings, creating dummy')
            self._create_dummy_embeddings(data_dir, output_dir)
    
    def _load_s4_embeddings(self, data_dir):
        """Try loading embeddings from Simple-HHEA S4 format."""
        import numpy as np
        ent1_embs = None
        ent2_embs = None
        try:
            # S4 may store embeddings as memory-mapped numpy arrays
            for emb_name in ['ent_embs.npy', 'entity_embeddings.npy']:
                p = os.path.join(data_dir, 'message_pool', emb_name)
                if os.path.exists(p):
                    all_embs = np.load(p)
                    # Try to split by entity counts
                    ent1_count = len(open(os.path.join(data_dir, 'ent_ids_1')).readlines())
                    ent2_count = len(open(os.path.join(data_dir, 'ent_ids_2')).readlines())
                    ent1_embs = all_embs[:ent1_count]
                    ent2_embs = all_embs[ent1_count:ent1_count+ent2_count]
                    break
        except Exception as e:
            print(f'[HyDRA] S4 embedding load failed: {e}')
        return ent1_embs, ent2_embs
    
    def _fallback_encode(self, data_dir):
        """Fallback: encode entity names using ALBERT."""
        try:
            from transformers import AlbertModel, AlbertTokenizer
            import torch
            import os as _os
            # Use local model cache to avoid HF connection issues
            _os.environ.setdefault('HF_ENDPOINT', 'https://hf-mirror.com')
            _os.environ['TRANSFORMERS_OFFLINE'] = '1'  # Force offline, use cache
            _os.environ['HF_HUB_OFFLINE'] = '1'
            
            model_path = '/root/autodl-tmp/HyDRA/models/albert-base-v2'
            if not _os.path.exists(model_path):
                model_path = 'albert-base-v2'
            tokenizer = AlbertTokenizer.from_pretrained(model_path, local_files_only=True)
            model = AlbertModel.from_pretrained(model_path, local_files_only=True)
            
            device = self.conf.torch_device if hasattr(self.conf, 'torch_device') else torch.device('cpu')
            model = model.to(device)
            model.eval()
            
            def encode_entities(ent_ids_file):
                names = []
                with open(ent_ids_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        parts = line.strip().split('\t')
                        if len(parts) >= 2:
                            names.append(parts[1])
                        else:
                            names.append(parts[0])
                
                embeddings = []
                batch_size = 64
                for i in range(0, len(names), batch_size):
                    batch = names[i:i+batch_size]
                    inputs = tokenizer(batch, padding=True, truncation=True, 
                                      max_length=128, return_tensors='pt')
                    inputs = {k: v.to(device) for k, v in inputs.items()}
                    with torch.no_grad():
                        outputs = model(**inputs)
                        # Use [CLS] token or mean pooling
                        emb = outputs.last_hidden_state[:, 0, :].cpu().numpy()
                    embeddings.append(emb)
                return np.concatenate(embeddings, axis=0) if embeddings else np.zeros((len(names), 768))
            
            ent1_embs = encode_entities(os.path.join(data_dir, 'ent_ids_1'))
            ent2_embs = encode_entities(os.path.join(data_dir, 'ent_ids_2'))
            return ent1_embs, ent2_embs
        except Exception as e:
            print(f'[HyDRA] Fallback encoding failed: {e}')
            return None, None
    
    def _create_dummy_embeddings(self, data_dir, output_dir):
        """Create dummy embeddings as last resort."""
        ent1_n = sum(1 for _ in open(os.path.join(data_dir, 'ent_ids_1')))
        ent2_n = sum(1 for _ in open(os.path.join(data_dir, 'ent_ids_2')))
        dim = 768
        
        np.random.seed(42)
        ent1_embs = np.random.randn(ent1_n, dim).astype(np.float32)
        ent2_embs = np.random.randn(ent2_n, dim).astype(np.float32)
        
        all_embs = np.concatenate([ent1_embs, ent2_embs], axis=0)
        np.savez(
            os.path.join(output_dir, 'emb.npz'),
            embs=all_embs,
            ent1_ids=np.arange(ent1_n),
            ent2_ids=np.arange(ent1_n, ent1_n + ent2_n),
        )
    
    def predict_simi(self):
        """Predict similarity matrix from embeddings."""
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        ent1_embs = embs[ent1_ids]
        ent2_embs = embs[ent2_ids]
        
        evaluator = Evaluator(device=self.conf.torch_device)
        simi_mtx = evaluator.csls_sim(ent1_embs, ent2_embs, k=10)
        return simi_mtx
    
    def get_embeddings(self):
        """Get entity embeddings."""
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        return embs[ent1_ids], embs[ent2_ids]
    
    def get_pred_alignment(self, eval_way='sinkhorn'):
        """Get predicted alignment from output file."""
        pred_fn = os.path.join(self.conf.output_dir, 'pred_alignment.json')
        if os.path.exists(pred_fn):
            with open(pred_fn) as f:
                obj = json.loads(f.read())
            if eval_way == 'sinkhorn':
                return obj.get('pred_alignment_sinkhorn', [])
            elif eval_way == 'csls':
                return obj.get('pred_alignment_csls', [])
            elif eval_way == 'cosine':
                return obj.get('pred_alignment_cos', [])
        return []
    
    def evaluate(self, eval_way='sinkhorn'):
        """Evaluate using standard Sinkhorn/CSLS/Cosine pipeline.
        
        This is IDENTICAL to RREAModule.evaluate() — the evaluation logic
        only depends on entity embeddings, not on which model produced them.
        """
        print('[HyDRA] evaluate')
        
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        ent1_embs = embs[ent1_ids]
        ent2_embs = embs[ent2_ids]
        
        eval_alignment = read_alignment(os.path.join(self.conf.data_dir, 'test_alignment.txt'))
        
        evaluator = Evaluator(device=self.conf.torch_device)
        
        sinkhorn_test_metrics, sinkhorn_test_alignment = [], []
        csls_test_metrics, csls_test_alignment = [], []
        cosine_test_metrics, cosine_test_alignment = [], []
        
        if eval_way == 'sinkhorn':
            sinkhorn_test_metrics, sinkhorn_test_alignment = evaluator.evaluate_sinkhorn(
                ent1_embs, ent2_embs, eval_alignment)
            sinkhorn_test_alignment = sinkhorn_test_alignment.tolist()
        elif eval_way == 'csls':
            csls_test_metrics, csls_test_alignment = evaluator.evaluate_csls(
                ent1_embs, ent2_embs, eval_alignment)
            csls_test_alignment = csls_test_alignment.tolist()
        elif eval_way == 'cosine':
            cosine_test_metrics, cosine_test_alignment = evaluator.evaluate_cosine(
                ent1_embs, ent2_embs, eval_alignment)
            cosine_test_alignment = cosine_test_alignment.tolist()
        
        all_alignment = evaluator.predict_alignment(ent1_embs, ent2_embs, eval_way=eval_way)
        
        metrics_obj = {
            'metrics_sinkhorn': sinkhorn_test_metrics,
            'metrics_csls': csls_test_metrics,
            'metrics_cos': cosine_test_metrics,
        }
        pred_alignment_obj = {
            'pred_alignment_sinkhorn': sinkhorn_test_alignment,
            'pred_alignment_csls': csls_test_alignment,
            'pred_alignment_cos': cosine_test_alignment,
            'all_pred_alignment': all_alignment.tolist(),
        }
        
        with open(os.path.join(self.conf.output_dir, 'metrics.json'), 'w+') as f:
            f.write(json.dumps(metrics_obj))
        with open(os.path.join(self.conf.output_dir, 'pred_alignment.json'), 'w+') as f:
            f.write(json.dumps(pred_alignment_obj))
        with open(os.path.join(self.conf.output_dir, 'eval_metrics.json'), 'w+') as f:
            if eval_way == 'sinkhorn':
                f.write(json.dumps(sinkhorn_test_metrics))
            elif eval_way == 'csls':
                f.write(json.dumps(csls_test_metrics))
            elif eval_way == 'cosine':
                f.write(json.dumps(cosine_test_metrics))
        
        return metrics_obj
    
    def evaluate_given_alignment(self, eval_alignment):
        """Evaluate with a given alignment (used by framework for re-evaluation)."""
        emb_res = np.load(os.path.join(self.conf.output_dir, 'emb.npz'))
        embs = emb_res['embs']
        ent1_ids = emb_res['ent1_ids']
        ent2_ids = emb_res['ent2_ids']
        ent1_embs = embs[ent1_ids]
        ent2_embs = embs[ent2_ids]
        
        evaluator = Evaluator(device=self.conf.torch_device)
        sinkhorn_test_metrics, _ = evaluator.evaluate_sinkhorn(ent1_embs, ent2_embs, eval_alignment)
        csls_test_metrics, _ = evaluator.evaluate_csls(ent1_embs, ent2_embs, eval_alignment)
        cos_test_metrics, _ = evaluator.evaluate_cosine(ent1_embs, ent2_embs, eval_alignment)
        
        metrics_obj = {
            'metrics_sinkhorn': sinkhorn_test_metrics,
            'metrics_csls': csls_test_metrics,
            'metrics_cos': cos_test_metrics,
        }
        print(metrics_obj)
        return sinkhorn_test_metrics, csls_test_metrics, cos_test_metrics
