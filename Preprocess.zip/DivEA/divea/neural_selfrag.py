# -*- coding: utf-8 -*-
"""Self-RAG Entity Alignment - Retrieval + Self-Reflection loop."""

import os, json, re, numpy as np
from typing import List, Tuple

from divea.util import Config
from divea.llm_ea.base_llm_ea import BaseLLMEAModule
from divea.llm_ea.llm_backend import LLMBackend, MockBackend


class SelfRAGModule(BaseLLMEAModule):
    method_name = "SelfRAG"

    def __init__(self, conf, llm_backend=None, top_k=20, max_reflections=3, confidence_threshold=0.5):
        super().__init__(conf, llm_backend)
        self.top_k = top_k
        self.max_reflections = max_reflections
        self.confidence_threshold = confidence_threshold

    def _run_alignment(self, data_dir, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        ent1_ids = sorted(self._entity_texts_1.keys())
        ent2_ids = sorted(self._entity_texts_2.keys())

        ent1_names = [self._entity_texts_1[i] for i in ent1_ids]
        ent2_names = [self._entity_texts_2[i] for i in ent2_ids]
        ent1_embs = self.llm.embed(ent1_names)
        ent2_embs = self.llm.embed(ent2_names)

        ent1_norm = ent1_embs / (np.linalg.norm(ent1_embs, axis=1, keepdims=True) + 1e-8)
        ent2_norm = ent2_embs / (np.linalg.norm(ent2_embs, axis=1, keepdims=True) + 1e-8)
        sim_matrix = ent1_norm @ ent2_norm.T
        top_k_indices = np.argsort(-sim_matrix, axis=1)[:, :self.top_k]

        predicted_pairs = []
        for i, e1 in enumerate(ent1_ids):
            candidates = [ent2_ids[j] for j in top_k_indices[i][:self.top_k]]
            result = self._self_reflective_match(e1, candidates)
            if result is not None:
                predicted_pairs.append((e1, result))

        print("[SelfRAG] Predicted {} pairs".format(len(predicted_pairs)))
        with open(os.path.join(output_dir, "selfrag_predictions.json"), "w") as f:
            json.dump({"pairs": predicted_pairs}, f)
        return predicted_pairs

    def _self_reflective_match(self, e1, candidates):
        name1 = self._entity_texts_1.get(e1, "E{}".format(e1))
        neighbors1 = self._get_neighbor_texts(e1, kg=1)

        candidate_list = []
        for e2 in candidates:
            name2 = self._entity_texts_2.get(e2, "E{}".format(e2))
            neighbors2 = self._get_neighbor_texts(e2, kg=2)
            candidate_list.append((e2, name2, neighbors2))

        # Initial retrieval + generation
        initial_prompt = self._build_retrieval_prompt(name1, neighbors1, candidate_list)
        initial_response = self.llm.generate(initial_prompt,
            system_prompt="Entity alignment with retrieval. Output: ID and confidence (0-1). Format: ID: N, confidence: X.XX",
            temperature=0.1, max_tokens=256)

        current_best, confidence = self._parse_confidence(initial_response, [c[0] for c in candidate_list])

        # Self-reflection loop
        for reflection_round in range(self.max_reflections):
            if confidence >= self.confidence_threshold:
                break
            if current_best is None:
                break
            reflect_prompt = self._build_reflection_prompt(
                name1, neighbors1, current_best, candidate_list, confidence)
            reflect_response = self.llm.generate(reflect_prompt,
                system_prompt="Critique and refine entity alignment. Output: ID and confidence.",
                temperature=0.3, max_tokens=256)
            new_best, new_conf = self._parse_confidence(reflect_response, [c[0] for c in candidate_list])
            if new_best is not None and new_conf > confidence:
                current_best = new_best
                confidence = new_conf
            else:
                break

        if confidence >= self.confidence_threshold:
            return current_best
        return None

    def _build_retrieval_prompt(self, name1, neighbors1, candidate_list):
        c_str = "\n".join(["  [{}] {} | neighbors: {}".format(e2, name2, n2) for e2, name2, n2 in candidate_list])
        return "Query entity: {}\nNeighbors: {}\n\nRetrieved candidates:\n{}\n\nIdentify the best match. Output format: ID: <id>, confidence: <0-1>".format(name1, neighbors1, c_str)

    def _build_reflection_prompt(self, name1, neighbors1, current_best, candidate_list, confidence):
        best_name = self._entity_texts_2.get(current_best, "E{}".format(current_best))
        c_str = "\n".join(["  [{}] {}".format(e2, name2) for e2, name2, _ in candidate_list])
        return "Previous prediction: [{}] {} (confidence: {:.2f})\nQuery: {} (neighbors: {})\nAll candidates:\n{}\n\nCritique the prediction. Is there a better candidate? Consider name similarity, structural patterns, and cross-lingual clues.\nOutput: ID: <id>, confidence: <0-1> (use the original ID if unchanged)".format(
            current_best, best_name, confidence, name1, neighbors1, c_str)

    def _parse_confidence(self, response, valid_ids):
        try:
            id_match = re.search(r"ID:\s*(\d+)", response, re.IGNORECASE)
            conf_match = re.search(r"confidence:\s*([0-9.]+)", response, re.IGNORECASE)
            if id_match and conf_match:
                pred_id = int(id_match.group(1))
                conf = float(conf_match.group(1))
                if pred_id in valid_ids:
                    return pred_id, conf
        except:
            pass
        numbers = re.findall(r"\d+", response)
        if numbers:
            pred_id = int(numbers[0])
            if pred_id in valid_ids:
                return pred_id, 0.5
        return None, 0.0